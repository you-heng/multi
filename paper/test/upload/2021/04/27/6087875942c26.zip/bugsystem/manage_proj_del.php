<?php include "./com/database.php";?>
<?php                                                     
$id = $_GET['project_id'];
getConnection();
$sql="delete from project where id = '$id' ";
echo $sql;
$res=mysqli_query($databaseConnection,$sql);
closeConnection();
if($res){
    echo'删除成功<a href="manage_proj_page.php">返回</a>';
    
}else{
    echo '删除失败'; 
}
?>