<?php include "./com/database.php";?>
<?php
$proj_name=$_POST['proj_name'];
//echo $proj_name;
$status=$_POST['status'];
//echo $status;
$view_state=$_POST['view_state'];
//echo $view_state;
$description=$_POST['description'];
//echo $description;
getConnection();
  $sql="insert into project(proj_name,status,view_state,description) values('$proj_name','$status','$view_state','$description')";
  $result=mysqli_query($databaseConnection,$sql);
  //var_dump($result);
  closeConnection();
  if($result){
      echo '添加成功<a href="manage_proj_page.php">返回首页</a>';
  }else{
      echo "添加失败";
  } 
?>