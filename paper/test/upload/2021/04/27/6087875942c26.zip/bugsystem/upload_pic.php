<?php include "./com/link.php"; ?>
<?php include "./com/menu.php"; ?>
<?php include "./com/showPic.php"; ?>
<div class="col-md-4 col-md-offset-4" style="padding-top: 10px;">
    <form action="upload.php" method="post" name="form" enctype="multipart/form-data">
        <!--每个文件上传框限制上传文件的大小-->
        <input type="hidden" name="MAX_FILE_SIZE" value="102400000000000000000000000000000000">
        <div id="upload"></div>
        <div class="form-group">
            
            <input type="button" value="单击新增" onclick="createUploader()">
            <p class="help-block">轮播图设置</p>
        </div>
        <div class="form-group"> 
            <input type="submit" value="上传">
        </div>
    </form>
</div>
<script>
    function createUploader() {
        var div = document.getElementById("upload");;
        var uploader = document.createElement("input");
        uploader.type = "file";
        uploader.name = "myFile[]";
        uploader.accept = "image/gif,image/jpg"; //设置上传文件格式
        div.appendChild(uploader);
        var br = document.createElement("br");
        div.appendChild(br);
    }
</script>