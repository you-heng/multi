<!DOCTYPE html
   PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN"  "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8" > 
  <?php include "../com/link.php";?>
  <div class="col-md-4 col-md-offset-4" style="padding-top: 150px;">
  <title>角色添加</title>
  <style type="text/css">
        body {
            background: url(img/4.jpg) no-repeat;
            background-size: cover;
        }
        .container {
            display: table;
            height: 100%;
        }
        .row {
            display: table-cell;
            vertical-align: middle;
        }
        /* centered columns styles */
        .row-centered {
            text-align: center;
        }
        .col-centered {
            display: inline-block;
            float: none;
            text-align: left;
            margin-right: -4px;
        }
    </style>
</head>
<body>
    <center>
  <h3>角色添加</h3>
  <form action="dorole.php" method="post">
  <p>角色名称:<input name="rolename" value=" " type="text"></p>
    <p><input type="submit" value="提交" /></p>
   </form>
   </center> 
</body>
</html>