<?php include "./com/database.php";

?>
<?php
$menu_name=$_POST['menu_name'];
$url_menu=$_POST['url_menu'];
getConnection();
  $sql="insert into t_user(menu_name,url_menu) values('$menu_name','$url_menu')";
  $result=del_insert_update_sql($sql);
 closeConnection();
  if($result){
      echo '添加成功<a href="menu_manage.php">返回首页</a>';
  }else{
      echo "添加失败";
  } 
?>