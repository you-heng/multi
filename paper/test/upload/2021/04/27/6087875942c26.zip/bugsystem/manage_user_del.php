<?php include "./com/database.php";?>
<?php                                                     
$id = $_GET['user_id'];
getConnection();
$sql="delete from t_user where Id = '$id' ";
echo $sql;
$res=mysqli_query($databaseConnection,$sql);
closeConnection();
if($res){
    echo'删除成功<a href="manage_user_page.php">返回</a>';
    
}else{
    echo '删除失败'; 
}
?>