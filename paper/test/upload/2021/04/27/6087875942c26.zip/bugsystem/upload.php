<?php
if(empty($_POST)){
    exit("您提交的表单数据超过post_max_size的配置！<br/>");
}
$count = count($_FILES['myFile']['name']);
$pic_info="img000";
for($i=0;$i<$count;$i++){
    $myFile=$_FILES['myFile'];
    $error =$myFile["error"][$i];
    switch($error){
        case 0:
            $fileName=$pic_info.($i+1).".jpg";  //$myFile['name'][$i];
            $fileTemp=$myFile['tmp_name'][$i];
            $destination="img/".iconv("utf-8","gb2312",$fileName);
            move_uploaded_file($fileTemp,$destination);
          
        break;
        case 1:
            echo "上传的某些文件超过了php.ini中upload_max_filesize选项限制的值！<br/>";
        break;
        case 2:  
            echo "上传的某些文件超过了FROM表单中MAX_FILE_SIZE选项指定的值！<br/>";
        break;
        case 3:
            echo "某些文件只有部分被上传!<br/>";
        break;
        case 4:
            echo "没有选择上传文件!<br/>";
        break;
            
    }
}
$showPic_url="./upload_pic.php";
Header("Location:$showPic_url");
?>