<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <title>项目管理</title>
    <?php include "./com/link.php"; ?>
    <?php include "./com/menu.php";?>
    <?php include "./com/database.php";?>
</head>
<div class="col-md-12 col-xs-12">
    <div class="space-10"></div>
    <div class="widget-box widget-color-blue2">
        <div class="widget-header widget-header-small">
        </div>
        <div class="widget-body">
            <div class="widget-main no-padding">
                <div class="widget-toolbox padding-8 clearfix">
                    <form method="post" action="manage_proj_create_page.php" class="form-inline inline single-button-form">
                        <fieldset>
                            <input type="hidden" name="manage_proj_create_page_token" value="20210309JIVFgP0llRE_HhHq6NyzBW_vWrQqPom9" />
                            <button type="submit" class="btn btn-primary btn-white btn-round">
                            <span class="glyphicon glyphicon-plus"></span>
                            创建新项目</button>
                        </fieldset>
                    </form>
                </div>
            <div class="panel-body">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                        <th>序号</th>
                        <th>项目名称</th>
                        <th>状态</th>
						<th>查看权限</th>
                        <th>描述</th>
                        <th>操作</th>
                        </tr> 
                    </thead>
                    <?php
                         $sql_project="select * from project";
                         $project_list=get_sql_list($sql_project);
                         $html="";
                        if(mysqli_num_rows($project_list)>0){
                          //输出数据
                          while($list_info=mysqli_fetch_array($project_list)){
                              $html .='<tr>';
                              $html .='<td>'.$list_info["id"].'</td>';
                              $html .='<td>'.$list_info["proj_name"].'</td>';
                              $html .='<td>'.$list_info["status"].'</td>';
							  $html .='<td>'.$list_info["view_state"].'</td>';
                              $html .='<td>'.$list_info["description"].'</td>';
                              $html .='<td> <a class="btn btn-primary" href="./manage_proj_update.php?project_id='.$list_info["id"].'"><i class="fa fa-pencil"></i>修改</a>';
                              $html .='     <a class="btn btn-danger"  href="./manage_proj_del.php?project_id=' .$list_info["id"].'"><i class="fa fa fa-trash-o"></i>删除</a></td>';
                              $html .='</tr>';
                          }
                          echo $html;
                      }else{
                          echo "暂无数据";
                      }
                    ?>
                </table>
            </div>
        </div>
        </div>
    </div>
</div>
</html>
                