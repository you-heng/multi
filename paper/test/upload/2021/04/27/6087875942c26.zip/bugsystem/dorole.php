<?php include "./com/database.php";?>
<?php
$rolename=$_POST['rolename'];
getConnection();
  $sql="insert into t_user(role_name) values('$rolename')";
  $result=del_insert_update_sql($sql);
 closeConnection();
  if($result){
      echo '添加成功<a href="role_manage.php">返回首页</a>';
  }else{
      echo "添加失败";
  } 
?>