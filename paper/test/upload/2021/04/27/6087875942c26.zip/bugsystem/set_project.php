<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN" "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
</head>
<!-- Project Select Form BEGIN -->
<div id="select-project-div" class="form-container">
	<form id="select-project-form" method="post" action="set_project.php">
			<div class="widget-box widget-color-blue2">
		<div class="widget-header widget-header-small">
			<h4 class="widget-title lighter">
				<i class="fa fa-puzzle-piece ace-icon" ></i>				选择项目			</h4>
		</div>
	<div class="widget-body">
	<div class="widget-main no-padding">
	<div class="table-responsive">
		<table class="table table-bordered table-condensed table-striped">
		<fieldset>
			<input type="hidden" name="ref" value="bug_report_page.php" />

			<tr>
				<td class="category">
					选择项目				</td>
				<td>
					<select id="select-project-id" name="project_id " class="input-sm">
						<option value="1">测试1</option>
                        <option value="2">测试2</option>
                        <option value="3">测试3</option>
					</select>
				</td>
			</tr>

			<tr>
				<td class="category">
					设为默认值				</td>
				<td>
					<label>
						<input type="checkbox" class="ace" id="set-default" name="make_default" />
						<span class="lbl"></span>
					</label>
				</td>
			</tr>
		</fieldset>
		</table>
		</div>
		</div>
			<div class="widget-toolbox padding-8 clearfix">
				<input type="submit" class="btn btn-primary btn-white btn-round" value="选择项目" />
			</div>
		</div>
	</div>
	</form>
</div>
</div>
