<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <meta name="robots" content="noindex,follow" />
    <title>我的视图</title>
    <?php include "./com/link.php"; ?>
    <?php include "./com/menu.php"; ?>
    <?php include "./com/database.php"; ?>
</head>
<div class="page-content">
    <div class="row">
        <div class="col-xs-12 col-md-7">
            <div id="assigned" class="widget-box widget-color-blue2 ">
                <div class="widget-header widget-header-small">
                    <h4 class="widget-title lighter">
                        <i class="fa fa-list-alt ace-icon"></i>
                        <a class="white" href="view_all_set.php?type=1&amp;temporary=y&amp;handler_id=1&amp;hide_status=80">分派给我的(未解决)</a>
                        <span class="badge"> 0 - 0 / 0 </span>
                    </h4>
                    <div class="widget-toolbar">
                        <a data-action="collapse" href="#">
                            <i class="fa fa-chevron-up 1 ace-icon bigger-125"></i> </a>
                    </div>
                    <div class="widget-toolbar no-border hidden-xs">
                        <div class="widget-menu">
                            <a class="btn btn-primary btn-white btn-round btn-sm" href="view_all_set.php?type=1&amp;temporary=y&amp;handler_id=1&amp;hide_status=80">查看问题</a>
                        </div>
                    </div>
                </div>

                <div class="widget-body">
                    <div class="widget-main no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-condensed table-striped table-hover">
                                <tbody>
                                    <tr>
                                        <td>&#160;</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="space-10"></div>
            <div id="unassigned" class="widget-box widget-color-blue2 ">
                <div class="widget-header widget-header-small">
                    <h4 class="widget-title lighter">
                        <i class="fa fa-list-alt ace-icon"></i><a class="white" href="view_all_set.php?type=1&amp;temporary=y&amp;handler_id=[none]&amp;hide_status=90">未分派的</a><span class="badge"> 0 - 0 / 0 </span>
                    </h4>
                    <div class="widget-toolbar">
                        <a data-action="collapse" href="#">
                            <i class="fa fa-chevron-up 1 ace-icon bigger-125"></i> </a>
                    </div>
                    <div class="widget-toolbar no-border hidden-xs">
                        <div class="widget-menu">
                            <a class="btn btn-primary btn-white btn-round btn-sm" href="view_all_set.php?type=1&amp;temporary=y&amp;handler_id=[none]&amp;hide_status=90">查看问题</a>
                        </div>
                    </div>
                </div>

                <div class="widget-body">
                    <div class="widget-main no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-condensed table-striped table-hover">
                                <tbody>
                                    <tr>
                                        <td>&#160;</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="space-10"></div>
            <div id="reported" class="widget-box widget-color-blue2 ">
                <div class="widget-header widget-header-small">
                    <h4 class="widget-title lighter">
                        <i class="fa fa-list-alt ace-icon"></i><a class="white" href="view_all_set.php?type=1&amp;temporary=y&amp;reporter_id=1&amp;hide_status=90">我报告的</a><span class="badge"> 0 - 0 / 0 </span>
                    </h4>
                    <div class="widget-toolbar">
                        <a data-action="collapse" href="#">
                            <i class="fa fa-chevron-up 1 ace-icon bigger-125"></i> </a>
                    </div>
                    <div class="widget-toolbar no-border hidden-xs">
                        <div class="widget-menu">
                            <a class="btn btn-primary btn-white btn-round btn-sm" href="view_all_set.php?type=1&amp;temporary=y&amp;reporter_id=1&amp;hide_status=90">查看问题</a>
                        </div>
                    </div>
                </div>

                <div class="widget-body">
                    <div class="widget-main no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-condensed table-striped table-hover">
                                <tbody>
                                    <tr>
                                        <td>&#160;</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="space-10"></div>
            <div id="resolved" class="widget-box widget-color-blue2 ">
                <div class="widget-header widget-header-small">
                    <h4 class="widget-title lighter">
                        <i class="fa fa-list-alt ace-icon"></i><a class="white" href="view_all_set.php?type=1&amp;temporary=y&amp;status=80&amp;hide_status=90">已解决的</a><span class="badge"> 0 - 0 / 0 </span>
                    </h4>
                    <div class="widget-toolbar">
                        <a data-action="collapse" href="#">
                            <i class="fa fa-chevron-up 1 ace-icon bigger-125"></i> </a>
                    </div>
                    <div class="widget-toolbar no-border hidden-xs">
                        <div class="widget-menu">
                            <a class="btn btn-primary btn-white btn-round btn-sm" href="view_all_set.php?type=1&amp;temporary=y&amp;status=80&amp;hide_status=90">查看问题</a>
                        </div>
                    </div>
                </div>

                <div class="widget-body">
                    <div class="widget-main no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-condensed table-striped table-hover">
                                <tbody>
                                    <tr>
                                        <td>&#160;</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="space-10"></div>
            <div id="recent_mod" class="widget-box widget-color-blue2 ">
                <div class="widget-header widget-header-small">
                    <h4 class="widget-title lighter">
                        <i class="fa fa-list-alt ace-icon"></i><a class="white" href="view_all_set.php?type=1&amp;temporary=y&amp;hide_status=none&amp;filter_by_last_updated_date=1&amp;last_updated_end_day=7&amp;last_updated_end_month=4&amp;last_updated_end_year=2021&amp;last_updated_start_day=8&amp;last_updated_start_month=3&amp;last_updated_start_year=2021">最近修改 (30 天)</a><span class="badge"> 0 - 0 / 0 </span>
                    </h4>
                    <div class="widget-toolbar">
                        <a data-action="collapse" href="#">
                            <i class="fa fa-chevron-up 1 ace-icon bigger-125"></i> </a>
                    </div>
                    <div class="widget-toolbar no-border hidden-xs">
                        <div class="widget-menu">
                            <a class="btn btn-primary btn-white btn-round btn-sm" href="view_all_set.php?type=1&amp;temporary=y&amp;hide_status=none&amp;filter_by_last_updated_date=1&amp;last_updated_end_day=7&amp;last_updated_end_month=4&amp;last_updated_end_year=2021&amp;last_updated_start_day=8&amp;last_updated_start_month=3&amp;last_updated_start_year=2021">查看问题</a>
                        </div>
                    </div>
                </div>

                <div class="widget-body">
                    <div class="widget-main no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-condensed table-striped table-hover">
                                <tbody>
                                    <tr>
                                        <td>&#160;</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="space-10"></div>
            <div id="monitored" class="widget-box widget-color-blue2 ">
                <div class="widget-header widget-header-small">
                    <h4 class="widget-title lighter">
                        <i class="fa fa-list-alt ace-icon"></i><a class="white" href="view_all_set.php?type=1&amp;temporary=y&amp;monitor_user_id=1&amp;hide_status=90">我监视的</a><span class="badge"> 0 - 0 / 0 </span>
                    </h4>
                    <div class="widget-toolbar">
                        <a data-action="collapse" href="#">
                            <i class="fa fa-chevron-up 1 ace-icon bigger-125"></i> </a>
                    </div>
                    <div class="widget-toolbar no-border hidden-xs">
                        <div class="widget-menu">
                            <a class="btn btn-primary btn-white btn-round btn-sm" href="view_all_set.php?type=1&amp;temporary=y&amp;monitor_user_id=1&amp;hide_status=90">查看问题</a>
                        </div>
                    </div>
                </div>

                <div class="widget-body">
                    <div class="widget-main no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-condensed table-striped table-hover">
                                <tbody>
                                    <tr>
                                        <td>&#160;</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>