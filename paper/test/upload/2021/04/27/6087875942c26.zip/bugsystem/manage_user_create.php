<?php include "./com/database.php";?>
<?php
$user=$_POST['username'];
$realname=$_POST['realname'];
$pwd=$_POST['pwd'];
$email=$_POST['email'];
$role=$_POST['role'];
getConnection();
  $sql="insert into t_user(username,realname,pwd,email,role_name) values('$user','$realname','$pwd','$email','$role')";
  $result=mysqli_query($databaseConnection,$sql);
 closeConnection();
  if($result){
      echo '添加成功<a href="manage_user_page.php">返回首页</a>';
  }else{
      echo "添加失败";
  } 
?>