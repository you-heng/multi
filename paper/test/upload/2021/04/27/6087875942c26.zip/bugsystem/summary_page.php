<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN" "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
    <title>摘要</title>
	<?php include "./com/link.php"; ?>
	<?php include "./com/menu.php"; ?>
	<?php include "./com/database.php"; ?>
</head>
<div class="col-md-12 col-xs-12">
    <div class="space-10"></div>

    <div class="widget-box widget-color-blue2">
        <div class="widget-header widget-header-small">
        </div>

        <div class="widget-body">
            <div class="widget-main no-padding">
                <!-- LEFT COLUMN -->
                <div class="col-md-6 col-xs-12">

                    <!-- BY PROJECT -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-35">按项目</th>
                                    <th class="align-right">开放</th>
                                    <th class="align-right">已解决</th>
                                    <th class="align-right">已关闭</th>
                                    <th class="align-right">总数</th>
                                    <th class="align-right">解决率</th>
                                    <th class="align-right">比率</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <!-- BY STATUS -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-35">按问题状态</th>
                                    <th class="align-right">开放</th>
                                    <th class="align-right">已解决</th>
                                    <th class="align-right">已关闭</th>
                                    <th class="align-right">总数</th>
                                    <th class="align-right">解决率</th>
                                    <th class="align-right">比率</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <!-- BY SEVERITY -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-35">按严重性</th>
                                    <th class="align-right">开放</th>
                                    <th class="align-right">已解决</th>
                                    <th class="align-right">已关闭</th>
                                    <th class="align-right">总数</th>
                                    <th class="align-right">解决率</th>
                                    <th class="align-right">比率</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <!-- BY CATEGORY -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-35">按分类</th>
                                    <th class="align-right">开放</th>
                                    <th class="align-right">已解决</th>
                                    <th class="align-right">已关闭</th>
                                    <th class="align-right">总数</th>
                                    <th class="align-right">解决率</th>
                                    <th class="align-right">比率</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <!-- TIME STATS -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th colspan="2">已解决问题的耗时(天)</th>
                                </tr>
                            </thead>
                            <tr>
                                <td>耗时最长的问题</td>
                                <td class="align-right"></td>
                            </tr>
                            <tr>
                                <td>最长耗时</td>
                                <td class="align-right">0.00</td>
                            </tr>
                            <tr>
                                <td>平均时间</td>
                                <td class="align-right">0.00</td>
                            </tr>
                            <tr>
                                <td>合计时间</td>
                                <td class="align-right">0.00</td>
                            </tr>
                        </table>
                    </div>

                    <!-- DEVELOPER STATS -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th>处理员(未解决/已解决/已关闭/合计)</th>
                                    <th class="align-right">开放</th>
                                    <th class="align-right">已解决</th>
                                    <th class="align-right">已关闭</th>
                                    <th class="align-right">总数</th>
                                    <th class="align-right">解决率</th>
                                    <th class="align-right">比率</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>

                <!-- RIGHT COLUMN -->
                <div class="col-md-6 col-xs-12">

                    <!-- BY DATE -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-35">按日期 (天)</th>
                                    <th class="align-right">已报告</th>
                                    <th class="align-right">已解决</th>
                                    <th class="align-right">差值</th>
                                </tr>
                            </thead>
                            <tr>
                                <td class="width50">1</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                            </tr>
                            <tr>
                                <td class="width50">2</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                            </tr>
                            <tr>
                                <td class="width50">3</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                            </tr>
                            <tr>
                                <td class="width50">7</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                            </tr>
                            <tr>
                                <td class="width50">30</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                            </tr>
                            <tr>
                                <td class="width50">60</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                            </tr>
                            <tr>
                                <td class="width50">90</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                            </tr>
                            <tr>
                                <td class="width50">180</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                            </tr>
                            <tr>
                                <td class="width50">365</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                                <td class="align-right">0</td>
                            </tr>
                        </table>
                    </div>

                    <!-- MOST ACTIVE -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-85">最活跃</th>
                                    <th class="align-right">得分</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <!-- LONGEST OPEN -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-85">最长耗时</th>
                                    <th class="align-right">天</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <!-- BY RESOLUTION -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-35">按处理状况</th>
                                    <th class="align-right">开放</th>
                                    <th class="align-right">已解决</th>
                                    <th class="align-right">已关闭</th>
                                    <th class="align-right">总数</th>
                                    <th class="align-right">解决率</th>
                                    <th class="align-right">比率</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <!-- BY PRIORITY -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-35">按优先级</th>
                                    <th class="align-right">开放</th>
                                    <th class="align-right">已解决</th>
                                    <th class="align-right">已关闭</th>
                                    <th class="align-right">总数</th>
                                    <th class="align-right">解决率</th>
                                    <th class="align-right">比率</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <!-- REPORTER STATS -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-35">报告员(未解决/已解决/已关闭/合计)</th>
                                    <th class="align-right">开放</th>
                                    <th class="align-right">已解决</th>
                                    <th class="align-right">已关闭</th>
                                    <th class="align-right">总数</th>
                                    <th class="align-right">解决率</th>
                                    <th class="align-right">比率</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <!-- REPORTER EFFECTIVENESS -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-35">报告员效率</th>
                                    <th class="align-right">严重性</th>
                                    <th class="align-right">无效</th>
                                    <th class="align-right">合计</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                </div>

                <!-- BOTTOM -->
                <div class="col-md-12 col-xs-12">

                    <!-- REPORTER BY RESOLUTION -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-15">报告员/处理状况</th>
                                    <th class="align-right">未处理</th>
                                    <th class="align-right">已修正</th>
                                    <th class="align-right">重新打开</th>
                                    <th class="align-right">无法重现</th>
                                    <th class="align-right">无法修复</th>
                                    <th class="align-right">重复问题</th>
                                    <th class="align-right">不必改</th>
                                    <th class="align-right">稍后处理</th>
                                    <th class="align-right">不做修改</th>
                                    <th class="align-right">合计</th>
                                    <th class="align-right">% 无效</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                    <!-- DEVELOPER BY RESOLUTION -->
                    <div class="space-10"></div>
                    <div class="widget-box table-responsive">
                        <table class="table table-hover table-bordered table-condensed table-striped">
                            <thead>
                                <tr>
                                    <th class="width-15">开发人员/处理状况</th>
                                    <th class="align-right">未处理</th>
                                    <th class="align-right">已修正</th>
                                    <th class="align-right">重新打开</th>
                                    <th class="align-right">无法重现</th>
                                    <th class="align-right">无法修复</th>
                                    <th class="align-right">重复问题</th>
                                    <th class="align-right">不必改</th>
                                    <th class="align-right">稍后处理</th>
                                    <th class="align-right">不做修改</th>
                                    <th class="align-right">合计</th>
                                    <th class="align-right">% 已修正</th>
                                </tr>
                            </thead>
                        </table>
                    </div>

                </div>

            </div>
        </div>
        <div class="clearfix"></div>
        <div class="space-10"></div>
    </div>
</div>