<?php include "./com/database.php";?>
<?php
$username=trim($_POST['username']);
$realname=trim($_POST['realname']);
$pwd=trim($_POST['pwd']);
$email=$_POST['email'];
$sql_select = "SELECT * FROM t_user WHERE username = '$username'"; //执行SQL语句
$result = get_sql_list($sql_select);
$num = mysqli_num_rows($result); 
    if($num){  //如果此用户已经被占用，则$num=1,否则，$num=0
       echo "此用户已经被占用。"."<a href='reg.php'>返回注册</a>";
    }else{
        $sql="insert into t_user(username,realname,pwd,email) values('$username','$realname','$pwd','$email')";
        $result=get_sql_list($sql);
        if($result){
            echo "注册成功，请重新登录。" ."<a href='login.php'>返回登录</a>";
        }else{
            echo "注册失败，请重新注册。" ."<a href='reg.php'>返回注册</a>";
        }
    }