<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <title>添加项目</title>
    <?php include "./com/link.php"; ?>
    <?php include "./com/menu.php"; ?>
    <?php include "./com/database.php"; ?>
</head>
<div class="col-md-12 col-xs-12">
    <div class="space-10"></div>
    <div id="manage-project-create-div" class="form-container">
        <form method="post" id="manage-project-create-form" action="manage_proj_create.php">
            <div class="widget-box widget-color-blue2">
                <div class="widget-header widget-header-small">
                    <h4 class="widget-title lighter">
                        <i class="ace-icon fa fa-puzzle-piece"></i>
                        添加项目
                    </h4>
                </div>
                <div class="widget-body">
                    <div class="widget-main no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-condensed table-striped">
                                <fieldset>
                                    <input type="hidden" name="manage_proj_create_token" value="20210309KzUqmjmoPY-4UPMfv8XSFFdFyDcZ_A4F" />
                                    <tr>
                                        <td class="category">
                                            <span class="required">*</span> 项目名称
                                        </td>
                                        <td>
                                            <input type="text" id="project-name" name="proj_name" class="input-sm" size="60" maxlength="128" required />
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="category">
                                            状态 </td>
                                        <td>
                                            <select id="project-status" name="status" class="input-sm">
                                                <option value="开发中">开发中</option>
                                                <option value="已发布">已发布</option>
                                                <option value="稳定">稳定</option>
                                                <option value="停止维护">停止维护</option>
                                            </select>
                                        </td>
                                    </tr>
                                 

                                    <tr>
                                        <td class="category">
                                            查看权限 </td>
                                        <td>
                                            <select id="project-view-state" name="view_state" class="input-sm">
                                                <option value="公开" selected="selected">公开</option>
                                                <option value="私有">私有</option>
                                            </select>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td class="category">
                                            描述 </td>
                                        <td>
                                            <textarea class="form-control" id="project-description" name="description" cols="70" rows="5"></textarea>
                                        </td>
                                    </tr>

                                </fieldset>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="widget-toolbox padding-8 clearfix">
                    <span class="required pull-right"> * 必填</span>
                    <input type="submit" class="btn btn-primary btn-white btn-round" value="添加项目" />
                </div>
            </div>
        </form>
    </div>
</div>