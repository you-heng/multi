<!DOCTYPE html
   PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN"  "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<title>编辑用户</title>
	<?php include "./com/link.php"; ?>
	<?php include "./com/menu.php"; ?>
    <?php include "./com/database.php";?>
</head>

<?php 
$id = $_GET['user_id'];
$sql_user = "select * from t_user where id='$id'";
$user_list = get_sql_list($sql_user);
if (mysqli_num_rows($user_list) > 0) {
    //输出数据
    while ($list_info = mysqli_fetch_array($user_list, MYSQLI_ASSOC)) {
        //print_r($list_info);
        //echo $list_info['proj_name'];
        //echo $list_info['status'];
        //echo $list_info['view_state'];
        //echo $list_info['id'];
    }
} else {
    echo "未找到用户";
    exit;
}
?>
       <center>
            <h3>用户信息修改</h3>
        </center>
      
<div class="col-lg-4 col-lg-offset-4" style="padding-top:100px">
        
<body>
<form action="douser.php" method="post">
    <input type="hidden" name="user_id" value="<?php echo $list_info['id']?>"/>
    <table style="border-collapse:collapse" border="1" width="80%" cellpadding="10"  bordercolor="gray">
        <tr>
        <td align="center">用户名 </td>
        <td>&nbsp;<input type="text" name="username" size="20" value=<?php echo $list_info['username'] ?> ></td>
        <br/>
       </tr>
       <tr>
        <td align="center">姓名 </td>
        <td>&nbsp;<input type="text" name="realname" size="20" value=<?php echo $list_info['realname'] ?> ></td>
       </tr>
       <tr>
        <td align="center">密码</td>
        <td>&nbsp;<input type="password" name="pwd" size="20" value=<?php echo $list_info['pwd'] ?> ></td>
       </tr>
       <tr>
       <tr>
        <td align="center">电子邮件</td>
        <td>&nbsp;<input type="text" name="email" size="20" value=<?php echo $list_info['email'] ?> ></td>
       </tr>
       <tr>
       <td align="center">角色</td>
        <td>
        <select id="role" name="role" >
               <option value="<?php echo  $list_info['role_name'];?>"><?php echo  $list_info['role_name'];?></option>
                <option name="管理员">管理员</option>
                <option name="测试人员">测试人员</option> 
               <option name="开发人员">开发人员</option>
                              
        </select></td>
       </tr>
       <tr>
          <td align="center" colspan="2" >
          <input type="submit" value="更新用户信息" ></td>
          </td>

       </tr>
 </table>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
</form>
</html>
</body>