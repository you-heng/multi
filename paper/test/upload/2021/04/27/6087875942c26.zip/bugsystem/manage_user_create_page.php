<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN" "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<title>创建新账户</title>
	<?php include "./com/link.php"; ?>
	<?php include "./com/menu.php";?>
    <?php include "./com/database.php";?>
</head>
<div class="col-md-12 col-xs-12">
	<div class="space-10"></div>
	<div id="manage-user-create-div" class="form-container">
		<form id="manage-user-create-form" method="post" action="manage_user_create.php">
			<div class="widget-box widget-color-blue2">
				<div class="widget-header widget-header-small">
				</div>
				<div class="widget-body">
					<div class="widget-main no-padding">
						<div class="table-responsive">
							<table class="table table-bordered table-condensed table-striped">
								<fieldset>
									<input type="hidden" name="manage_user_create_token" value="20210308R6nJWb5LwnaF3JjRyYLcZG8ns4h3P_3a" />
									<tr>
										<td class="category">
											用户名 </td>
										<td>
											<input type="text" id="user-username" name="username" class="input-sm" size="32" maxlength="191" />
										</td>
									</tr>
									<tr>
										<td class="category">
											姓名 </td>
										<td>
											<input type="text" id="user-realname" name="realname" class="input-sm" size="32" maxlength="255" />
										</td>
									</tr>
									<tr>
										<td class="category">
											密码 </td>
										<td>
											<input type="password" id="user-password" name="pwd" class="input-sm" size="32" maxlength="255" />
										</td>
									</tr>
									<tr>
										<td class="category">
											电子邮件 </td>
										<td>
											<input class="input-sm" id="email-field" type="text" name="email" size="32" maxlength="64" value="" />
										</td>
									</tr>
									<tr>
										<td class="category">
											角色 </td>
										<td>
											<select id="user-role" name="role" class="input-sm">
												<option value="开发人员">开发人员</option>
												<option value="测试人员" selected="selected">测试人员</option>
												<option value="管理员">管理员</option>
											</select>
										</td>
									</tr>
									<!--
									<tr>
										<td class="category">
											已启用 </td>
										<td>
											<label>
												<input type="checkbox" class="ace" id="user-enabled" name="enabled" checked="checked">
												<span class="lbl"></span>
											</label>
										</td>
									</tr>
									<tr>
										<td class="category">
											已保护 </td>
										<td>
											<label>
												<input type="checkbox" class="ace" id="user-protected" name="protected">
												<span class="lbl"></span>
											</label>
										</td>
									</tr>-->
								</fieldset>
							</table>
						</div>
					</div>
				</div>


				<div class="widget-toolbox padding-8 clearfix">
					<input type="submit" class="btn btn-primary btn-white btn-round" value="创建用户" />
				</div>
			</div>
	</div>
	    </form>
</div>