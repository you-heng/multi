<!DOCTYPE html
   PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN"  "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<title>软件信息</title>
	<?php include "./com/link.php"; ?>
	<?php include "./com/menu.php"; ?>
    <?php include "./com/database.php";?>
</head>
</ul>
<div id="sidebar-btn" class="sidebar-toggle sidebar-collapse">
<i data-icon2="ace-icon fa fa-angle-double-right" data-icon1="ace-icon fa fa-angle-double-left"
		class="ace-icon fa fa-angle-double-left"></i></div>
</div>
<div class="main-content">
<div id="breadcrumbs" class="breadcrumbs noprint">
</div>
  <div class="page-content">
<div class="row">
<ul class="nav nav-tabs padding-18">
<li class="active">
<a href="manage_overview_page.php"><i class="blue ace-icon fa fa-info-circle"></i> </a></li>
<li class="">
<a href="manage_overview_page.php">软件信息</a></li>
<li class="">
<a href="./manage_user_page.php">用户管理</a></li>
<li class="">
<a href="./manage_proj_page.php">项目管理</a></li>

<div class="col-md-12 col-xs-12">
	<div class="space-10"></div>
	<div class="widget-box widget-color-blue2">
	<div class="widget-header widget-header-small">
		<h4 class="widget-title lighter">
			<i class="ace-icon fa fa-info"></i>
			软件信息		</h4>
	</div>
	<div class="widget-body">
	<div class="widget-main no-padding">
	<div class="table-responsive">
	<table id="manage-overview-table" class="table table-hover table-bordered table-condensed">
		<tr>
			<th class="category">app名称</th>
			<td>中国银行手机银行</td>
		</tr>
		<tr class="spacer">
			<td colspan="2"></td>
		</tr>
		<tr>
			<th class="category">app版本</th>
			<td>6.11.1</td>
		</tr>
		<tr class="spacer">
			<td colspan="2"></td>
		</tr>
		<tr class="hidden"></tr>
			<th class="category">浏览器版本</th>
			<td>5.6.27</td>
		</tr>
		<tr class="spacer">
			<td colspan="2"></td>
		</tr>
		<tr>
			<th class="category">数据库驱动</th>
			<td>chormedriver</td>
		</tr>
		<tr class="spacer">
			<td colspan="2"></td>
		</tr>
		<tr>
			<th class="category">测试设备</th>
			<td>300	</td>
		</tr>
		<tr class="spacer">
			<td colspan="2"></td>
		</tr>
		</table>
	</div>
	</div>
	</div>
	</div>
</div>
</div>
</div>
</div>