<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <title>问题详情</title>
    <?php include "./com/link.php"; ?>
    <?php include "./com/menu.php"; ?>
    <?php include "./com/database.php"; ?>
</head>
<div class="col-md-12 col-xs-12">
    <div class="widget-box widget-color-blue2">
        <div class="widget-header widget-header-small">
            <h4 class="widget-title lighter"><i class="ace-icon fa fa-bars"></i>查看问题详情</h4>
        </div>
            <div class="widget-main no-padding">
                <div class="table-responsive">
                    <table class="table table-bordered table-condensed">
                        <tfoot>
                            <tr class="noprint">
                                <td colspan="6">
                                    <div class="btn-group">
                                        <div class="pull-left padding-right-8">
                                            <form method="post" action="bug_update_page.php" class="form-inline">
                                                <fieldset><input type="hidden" name="bug_update_page_token" value="202103118GWhD5_M5QL7IFhc-tlILi1RbKv6_to9" />
                                                <input type="hidden" name="bug_id" value="34" />
                                                <input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="编辑" />
                                                </fieldset>
                                            </form>
                                        </div>
                                        <div class="pull-left padding-right-8">
                                            <form method="post" action="bug_update.php" class="form-inline">
                                            <input type="hidden" name="bug_update_token" value="20210311Zr-l5jGR9UI55JkKo24QNzcK9zygXmY3" />
                                            <input type="hidden" name="last_updated" value="1615441035" /><input type="hidden" name="action_type" value="assign" />
                                            <input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="分派给：" /> 
                                            <select class="input-sm" name="handler_id">
                                                    <option value="1" selected="selected">自身</option>
                                                    <option value="1">报告员</option>
                                                    <option value="1">administrator</option>
                                                </select><input type="hidden" name="bug_id" value="34" />
                                            </form>
                                        </div>
                                        <div class="pull-left padding-right-8">
                                            <form method="post" action="bug_change_status_page.php" class="form-inline"><input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="将状态更改为：" /> <select name="new_status" class="input-sm">
                                                    <option value="20" selected="selected">反馈</option>
                                                    <option value="30">认可</option>
                                                    <option value="40">已确认</option>
                                                    <option value="50">已分配</option>
                                                    <option value="80">已解决</option>
                                                    <option value="90">已关闭</option>
                                                </select><input type="hidden" name="id" value="34" />
                                                <input type="hidden" name="change_type" value="change_status" />
                                            </form>
                                        </div>
                                        <div class="pull-left padding-right-2">
                                            <form method="post" action="bug_monitor_add.php" class="form-inline">
                                                <fieldset><input type="hidden" name="bug_monitor_add_token" value="20210311yRPYF_ak1rclDoFJKJ6igk1MFtWuM-r8" /> <input type="hidden" name="bug_id" value="34" />
                                                    <input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="监视" />
                                                </fieldset>
                                            </form>
                                        </div>
                                        <div class="pull-left padding-right-2"></div>
                                        <div class="pull-left padding-right-2">
                                            <form method="post" action="bug_change_status_page.php" class="form-inline">
                                                <fieldset><input type="hidden" name="bug_change_status_page_token" value="202103115cu0yZ_P8caOTRWg-aBwkGisgqDHH7-V" /> <input type="hidden" name="id" value="34" />
                                                    <input type="hidden" name="new_status" value="90" />
                                                    <input type="hidden" name="change_type" value="close" />
                                                    <input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="关闭" />
                                                </fieldset>
                                            </form>
                                        </div>
                                        <div class="pull-left padding-right-2">
                                            <form method="post" action="bug_actiongroup_page.php" class="form-inline">
                                                <fieldset><input type="hidden" name="bug_actiongroup_page_token" value="20210311N7AAxZg1dEJLCurVG8G8qHwl4SHAOEgS" /> <input type="hidden" name="bug_arr[]" value="34" />
                                                    <input type="hidden" name="action" value="MOVE" />
                                                    <input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="移动" />
                                                </fieldset>
                                            </form>
                                        </div>
                                        <div class="pull-left padding-right-2">
                                            <form method="post" action="bug_actiongroup_page.php" class="form-inline">
                                                <fieldset><input type="hidden" name="bug_actiongroup_page_token" value="20210311Png31vwjqTb-uVV3v3bW_DW_rnQ5ETLN" /> <input type="hidden" name="bug_arr[]" value="34" />
                                                    <input type="hidden" name="action" value="DELETE" />
                                                    <input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="删除" />
                                                </fieldset>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        </tfoot>
                        <tbody>
                            <tr class="bug-header">
                                <th class="bug-id category" width="15%">编号</th>
                                <th class="bug-project category" width="20%">项目</th>
                                <th class="bug-category category" width="15%">分类</th>
                                <th class="bug-view-status category" width="15%">查看权限</th>
                                <th class="bug-date-submitted category" width="15%">报告日期</th>
                                <th class="bug-last-modified category" width="20%">最后更新</th>
                            </tr>
                            <tr class="bug-header-data">
                                <td class="bug-id">0000034</td>
                                <td class="bug-project">测试项目</td>
                                <td class="bug-category">[所有项目] 1111</td>
                                <td class="bug-view-status">公开</td>
                                <td class="bug-date-submitted">2021-03-09 09:38</td>
                                <td class="bug-last-modified">2021-03-11 13:37</td>
                            </tr>
                            <tr class="spacer">
                                <td colspan="6"></td>
                            </tr>
                            <tr class="hidden"></tr>
                            <tr>
                                <th class="bug-reporter category">报告员</th>
                                <td class="bug-reporter">administrator</td>
                                <th class="bug-assigned-to category">分派给</th>
                                <td class="bug-assigned-to"></td>
                                <td colspan="2">&#160;</td>
                            </tr>
                            <tr>
                                <th class="bug-priority category">优先级</th>
                                <td class="bug-priority">中</td>
                                <th class="bug-severity category">严重性</th>
                                <td class="bug-severity">小错误</td>
                                <th class="bug-reproducibility category">出现频率</th>
                                <td class="bug-reproducibility">没有试验</td>
                            </tr>
                            <tr>
                                <th class="bug-status category">状态</th>
                                <td class="bug-status"><i class="fa fa-square fa-status-box status-10-fg"></i> 新建</td>
                                <th class="bug-resolution category">处理状况</th>
                                <td class="bug-resolution">未处理</td>
                                <td colspan="2">&#160;</td>
                            </tr>
                            <tr class="spacer">
                                <td colspan="6"></td>
                            </tr>
                            <tr class="hidden"></tr>
                            <tr>
                                <th class="bug-summary category">摘要</th>
                                <td class="bug-summary" colspan="5">0000034: rfaetr哈哈有天然的</td>
                            </tr>
                            <tr>
                                <th class="bug-description category">描述</th>
                                <td class="bug-description" colspan="5">
                                    <p>2玩二五放入提高人体行业经验和</p>
                                </td>
                            </tr>
                            
                            <tr class="spacer">
                                <td colspan="6"></td>
                            </tr>
                            <tr class="hidden"></tr>
                            <tr class="spacer">
                                <td colspan="6"></td>
                            </tr>
                            <tr class="hidden"></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12 col-xs-12"><a id="monitors"></a>
    <div class="space-10"></div>
    <div id="monitoring" class="widget-box widget-color-blue2 ">
        <div class="widget-header widget-header-small">
            <h4 class="widget-title lighter">
                <i class="ace-icon fa fa-users"></i>
                正在监视该问题的用户
            </h4>
            <div class="widget-toolbar">
                <a data-action="collapse" href="#">
                    <i class="1 ace-icon fa fa-chevron-up bigger-125"></i>
                </a>
            </div>
        </div>

        <div class="widget-body">
            <div class="widget-main no-padding">

                <div class="table-responsive">
                    <table class="table table-bordered table-condensed table-striped">
                        <tr>
                            <th class="category" width="15%">
                                用户列表 </th>
                            <td>
                                当前没有用户监视这个问题。 <br /><br />
                                <form method="get" action="bug_monitor_add.php" class="form-inline noprint">
                                    <input type="hidden" name="bug_monitor_add_token" value="20210311fqYPXNedcqwFkZT4HpGDABsKWvCF5XqI" /> <input type="hidden" name="bug_id" value="34" />
                                    <label for="bug_monitor_list_username">用户名</label>
                                    <input type="text" class="input-sm" id="bug_monitor_list_username" name="username" />
                                    <input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="添加" />
                                </form>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>