<!DOCTYPE html>
<html>
    <head>
        <title>首页</title>
        <meta charset="utf-8">
        <?php include "./com/link.php";?>
    </head>
    <body>
        <?php include "./com/menu.php";?>
        <?php include "./com/showPic.php";?>
    </body>
</html>