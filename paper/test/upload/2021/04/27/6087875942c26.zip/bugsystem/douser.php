<?php include "./com/database.php";?>
<?php
session_start();
$id = $_POST['user_id'];
$username = $_POST['username']; 
$realname = $_POST['realname'];
$pwd= $_POST['pwd'];
$email = $_POST['email'];
$role = $_POST['role'];
$sql_user = "UPDATE t_user SET username = '$username', realname='$realname', pwd='$pwd', email='$email',role_name='$role' WHERE id='$id'";
$user_list=del_insert_update_sql($sql_user);
echo $sql_user;
echo mysqli_error($databaseConnection);
exit;

if($user_list)
{
  alert("编辑成功");
  href("manage_user_page.php");
}else{
  alert("编辑失败");
}
function alert($title){
  echo "<script type='text/javascript'>alert('$title');</script>";
}
function href($url){
  echo "<script type='text/javascript'>window.location.href='$url'</script>";
}
?>