<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <title>问题更新</title>
    <?php include "./com/link.php"; ?>
    <?php include "./com/menu.php"; ?>
    <?php include "./com/database.php"; ?>
</head>
<div class="col-md-12 col-xs-12">
    <div id="bug-update" class="form-container">
        <form id="update_bug_form" method="post" action="bug_update.php">
            <input type="hidden" name="bug_update_token" value="20210311h59aoYXeaGX2TTuD7S7R4z5IUdQQSR_T" /> 
            <input type="hidden" name="bug_id" value="32" />
            <input type="hidden" name="last_updated" value="1614253702" />

            <div class="widget-box widget-color-blue2">
                <div class="widget-header widget-header-small">
                    <h4 class="widget-title lighter">
                        <i class="ace-icon fa fa-comments"></i>
                        正在更新问题信息
                    </h4>
                    <div class="widget-toolbar no-border">
                        <div class="widget-menu">
                            <a class="btn btn-primary btn-white btn-round btn-sm" href="view.php?id=32">返回到问题</a>
                        </div>
                    </div>
                </div>
                <div class="widget-body">
                    <div class="widget-main no-padding">
                        <div class="table-responsive">
                            <table class="table table-bordered table-condensed table-striped">

                                <tbody>
                                    <tr>
                                        <td width="15%" class="category">编号</td>
                                        <td width="20%" class="category">项目</td>
                                        <td width="15%" class="category"><label for="category_id">分类</label></td>
                                        <td width="20%" class="category"><label for="view_state">查看权限</label></td>
                                        <td width="15%" class="category">报告日期</td>
                                        <td width="15%" class="category">最后更新</td>
                                    </tr>
                                    <tr>
                                        <td>0000032</td>
                                        <td>stock</td>
                                        <td><select tabindex="1" id="category_id" name="category_id" class="input-sm">
                                                <option value="1" selected="selected">[所有项目] 1111</option>
                                            </select></td>
                                        <td><select tabindex="2" id="view_state" name="view_state" class="input-sm">
                                                <option value="10" selected="selected">公开</option>
                                                <option value="50">私有</option>
                                            </select></td>
                                        <td>2021-02-25 19:46</td>
                                        <td>2021-02-25 19:48</td>
                                    </tr>
                                    <tr class="spacer">
                                        <td colspan="6"></td>
                                    </tr>
                                    <tr class="hidden"></tr>
                                    <tr>
                                        <th class="category"><label for="reporter_id">报告员</label></th>
                                        <td><select tabindex="3" id="reporter_id" name="reporter_id">
                                                <option value="1" selected="selected">administrator</option>
                                                <option value="6">BBQ (piupiupiu)</option>
                                                <option value="19">chair</option>
                                                <option value="17">ERICZHONG (EZHONG4)</option>
                                                <option value="11">FTTY</option>
                                                <option value="3">hello</option>
                                                <option value="15">hellobaby</option>
                                                <option value="13">hur</option>
                                                <option value="10">lidengke</option>
                                                <option value="2">mhugh</option>
                                                <option value="14">xiongc</option>
                                                <option value="16">xxxx (xxx)</option>
                                                <option value="12">yexx</option>
                                                <option value="8">Zhang</option>
                                                <option value="20">zhangsan (zz)</option>
                                                <option value="4">zhourunfa</option>
                                                <option value="5">zhourunfa0225</option>
                                                <option value="18">刘思思 (lss)</option>
                                                <option value="7">雷肖文 (ANMINSTRATOR)</option>
                                            </select></td>
                                        <th class="category"><label for="handler_id">分派给</label></th>
                                        <td><select tabindex="4" id="handler_id" name="handler_id" class="input-sm">
                                                <option value="0"></option>
                                                <option value="1">administrator</option>
                                                <option value="6">BBQ (piupiupiu)</option>
                                                <option value="19">chair</option>
                                                <option value="17">ERICZHONG (EZHONG4)</option>
                                                <option value="11">FTTY</option>
                                                <option value="3">hello</option>
                                                <option value="15">hellobaby</option>
                                                <option value="13">hur</option>
                                                <option value="10">lidengke</option>
                                                <option value="2">mhugh</option>
                                                <option value="14">xiongc</option>
                                                <option value="16">xxxx (xxx)</option>
                                                <option value="12">yexx</option>
                                                <option value="8">Zhang</option>
                                                <option value="20">zhangsan (zz)</option>
                                                <option value="4">zhourunfa</option>
                                                <option value="5">zhourunfa0225</option>
                                                <option value="18">刘思思 (lss)</option>
                                                <option value="7">雷肖文 (ANMINSTRATOR)</option>
                                            </select></td>
                                        <td colspan="2">&#160;</td>
                                    </tr>
                                    <tr>
                                        <th class="category"><label for="priority">优先级</label></th>
                                        <td><select tabindex="5" id="priority" name="priority" class="input-sm">
                                                <option value="10">无</option>
                                                <option value="20">低</option>
                                                <option value="30" selected="selected">中</option>
                                                <option value="40">高</option>
                                                <option value="50">紧急</option>
                                                <option value="60">非常紧急</option>
                                            </select></td>
                                        <th class="category"><label for="severity">严重性</label></th>
                                        <td><select tabindex="6" id="severity" name="severity" class="input-sm">
                                                <option value="10">新功能</option>
                                                <option value="20">细节</option>
                                                <option value="30">文字</option>
                                                <option value="40">小调整</option>
                                                <option value="50" selected="selected">小错误</option>
                                                <option value="60">很严重</option>
                                                <option value="70">崩溃</option>
                                                <option value="80">宕机</option>
                                            </select></td>
                                        <th class="category"><label for="reproducibility">出现频率</label></th>
                                        <td><select tabindex="7" id="reproducibility" name="reproducibility" class="input-sm">
                                                <option value="10">总是</option>
                                                <option value="30" selected="selected">有时</option>
                                                <option value="50">随机</option>
                                                <option value="70">没有试验</option>
                                                <option value="90">无法重现</option>
                                                <option value="100">不适用</option>
                                            </select></td>
                                    </tr>
                                    <tr>
                                        <th class="category"><label for="status">状态</label></th>
                                        <td class="bug-status"><i class="fa fa-square fa-status-box status-10-fg"></i> <select class="input-sm" tabindex="8" id="status" name="status">
                                                <option value="10" selected="selected">新建</option>
                                                <option value="20">反馈</option>
                                                <option value="30">认可</option>
                                                <option value="40">已确认</option>
                                                <option value="50">已分配</option>
                                                <option value="80">已解决</option>
                                                <option value="90">已关闭</option>
                                            </select></td>
                                        <th class="category"><label for="resolution">处理状况</label></th>
                                        <td><select tabindex="9" id="resolution" name="resolution" class="input-sm">
                                                <option value="10" selected="selected">未处理</option>
                                                <option value="20">已修正</option>
                                                <option value="30">重新打开</option>
                                                <option value="40">无法重现</option>
                                                <option value="50">无法修复</option>
                                                <option value="60">重复问题</option>
                                                <option value="70">不必改</option>
                                                <option value="80">稍后处理</option>
                                                <option value="90">不做修改</option>
                                            </select></td>
                                        <td colspan="2">&#160;</td>
                                    </tr>
                                    <tr>
                                        <th class="category"><label for="platform">平台</label></th>
                                        <td><input type="text" id="platform" name="platform" class="typeahead input-sm" autocomplete="off" size="16" maxlength="32" tabindex="10" value="" /></td>
                                        <th class="category"><label for="os">操作系统</label></th>
                                        <td><input type="text" id="os" name="os" class="typeahead input-sm" autocomplete="off" size="16" maxlength="32" tabindex="11" value="" /></td>
                                        <th class="category"><label for="os_build">操作系统版本</label></th>
                                        <td><input type="text" id="os_build" name="os_build" class="typeahead input-sm" autocomplete="off" size="16" maxlength="16" tabindex="12" value="" /></td>
                                    </tr>
                                    <tr class="spacer">
                                        <td colspan="6"></td>
                                    </tr>
                                    <tr class="hidden"></tr>
                                    <tr>
                                        <th class="category"><label for="summary">摘要</label></th>
                                        <td colspan="5"><input tabindex="13" type="text" id="summary" name="summary" size="105" maxlength="128" value="卡顿" /></td>
                                    </tr>
                                    <tr>
                                        <th class="category"><label for="description">描述</label></th>
                                        <td colspan="5"><textarea tabindex="14" style="width:100%; height:150px; border-style:none; " id="description" name="description">&lt;p&gt;卡顿了&lt;/p&gt;</textarea>
                                            <script type="text/javascript">
                                                var ue = UE.getEditor('description');
                                            </script>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th class="category">私有</th>
                                        <td colspan="5"><label><input tabindex="18" type="checkbox" class="ace" id="private" name="private" /><span class="lbl"></span></label></td>
                                    </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="widget-toolbox padding-8 clearfix">
                    <input type="submit" class="btn btn-primary btn-white btn-round" value="更新信息" />
                </div>

            </div>
        </form>
    </div>
</div>


