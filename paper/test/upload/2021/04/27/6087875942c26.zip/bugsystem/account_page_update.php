<?php
session_start();
include "./com/database.php";
$username=trim($_POST['username']);
$realname=trim($_POST['realname']);
$email=$_POST['email'];
//修改数据库记录
$sql="update t_user set realname='$realname',email='$email',role_name='$role' where username='$username'";
$result=del_insert_update_sql($sql);
if($result){
    echo "资料更新成功"."<a href='account_page.php'>返回登录</a>";
}else{
    echo "资料更新失败"."<a href='account_page.php'>返回登录</a>";
}
/*$logged=$_SESSION['logged'];
if($logged){
    //说明已经登录
    echo "欢迎 $logged 登录";
}else{
    echo "请登录后访问本页面"  ."<a href='login.php'>返回登录</a>";
}*/

?>