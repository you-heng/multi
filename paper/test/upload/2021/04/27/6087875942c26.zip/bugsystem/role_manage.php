<meta http-equiv="Content-Type" content="test/html;charset=UTF-8">
        <?php include "./com/link.php";?>
        <?php include "./com/menu.php";?>
        <?php include "./com/database.php";?>
        <div class="col-lg-12" style="padding-top:0px">
        <div class="panel panel-default">
            <div class="panel-heading">
                <button type="button" class="btn btn-primary">
                    <span class="glyphicon glyphicon-plus"></span>   新增角色
                </button>
            </div>
            <div class="panel-body">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                        <th>序号</th>
                        <th>角色名称</th>
                        <th>操作</th>
                        </tr> 
                    </thead>
                    <?php
                    $sql_role="select * from t_role";
                    $role_list=get_sql_list($sql_role);
                      $html="";
                      if(mysqli_num_rows($role_list)>0){
                          //输出数据
                          while($list_info=mysqli_fetch_array($role_list)){
                              $html .='<tr>';
                              $html .='<td>'.$list_info["id"].'</td>';
                              $html .='<td>'.$list_info["role_name"].'</td>';
                              $html .='<td> <a class="btn btn-primary" href="./role_update.php?role_id='.$list_info["id"].'"><i class="fa fa-pencil"></i>修改</a>';
                              $html .='     <a class="btn btn-danger"  href="./role_del.php?role_id=' .$list_info["id"].'"><i class="fa fa fa-trash-o"></i>删除</a>';
                              $html .='     <a class="btn btn-danger"  href="./role_menu.php?role_id=' .$list_info["id"].'"><i class="fa fa fa-trash-o"></i>菜单权限设定</a></td>';
                              $html .='</tr>';
                          }
                          echo $html;
                          echo '<a href="role_add.php">角色添加</a>';
                      }else{
                          echo "暂无数据";
                      }
                    ?>
                </table>
            </div>
        </div>
        </div>