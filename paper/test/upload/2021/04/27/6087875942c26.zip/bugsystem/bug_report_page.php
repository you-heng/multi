<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN" "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<title>输入问题详情</title>
	<?php include "./com/link.php"; ?>
	<?php include "./com/menu.php"; ?>
	<?php include "./com/database.php"; ?>
</head>
<body>
<?php
$sql_project="select * from project ";
$project_list=get_sql_list($sql_project);
if (mysqli_num_rows($project_list) > 0) {
    //输出数据
    while ($list_info = mysqli_fetch_array($project_list, MYSQLI_ASSOC)) {
        //print_r($list_info);
        echo $list_info['proj_name'];
        //echo $list_info['status'];
        //echo $list_info['view_state'];
    }
} else {
    echo "暂无数据";
    exit;
}
?>
<div class="page-content">
	<div class="row">
		<div class="col-md-12 col-xs-12">
			<form id="report_bug_form" method="post" enctype="multipart/form-data" action="bug_report.php">
				<input type="hidden" name="bug_report_token" value="20210407ge6kwTcnsf7BwewwcQHdQjRPGFbDv28X" />
				<input type="hidden" name="m_id" value="0" />
				<input type="hidden" name="project_id" value="5" />
				<div class="widget-box widget-color-blue2">
					<div class="widget-header widget-header-small">
					</div>
					<div class="widget-body dz-clickable">
						<div class="widget-main no-padding">
							<div class="table-responsive">
								<table class="table table-bordered table-condensed">
									<tr>
										<th class="category" width="30%">
											<span class="required">*</span> <label for="proj_name">项目名称</label>
										</th>
										<td width="70%">
											<select id="proj_name" name="proj_name" class="input-sm" tabindex="1" required>
												<option value="<?php $list_info['proj_name'] ?>" disabled hidden selected="selected">(请选择)</option>
											</select>
										</td>
									</tr>

									<tr>
										<th class="category">
											<label for="reproducibility">严重等级</label>
										</th>
										<td>
											<select tabindex="2" id="reproducibility" name="reproducibility" class="input-sm">
												<option value="非常严重的缺陷">非常严重的缺陷</option>
												<option value="较严重的缺陷">较严重的缺陷</option>
												<option value="软件一般缺陷">软件一般缺陷</option>
												<option value="软件界面的细微缺陷" selected="selected">软件的细微缺陷</option>
											</select>
										</td>
									</tr>
									<tr>
										<th class="category">
											<label for="severity">问题类型</label>
										</th>
										<td>
											<select tabindex="3" id="severity" name="severity" class="input-sm">
												<option value="UI异常">UI异常</option>
												<option value="运行失败">运行失败</option>
												<option value="功能异常">功能异常</option>
												<option value="安装失败">安装失败</option>
												<option value="启动失败">启动失败</option>
												<option value="其他报错" selected="selected">其他报错</option>
											</select>
										</td>
									</tr>
									<tr>
										<th class="category">
											<label for="priority">优先级</label>
										</th>
										<td>
											<select tabindex="4" id="priority" name="priority" class="input-sm">
												<option value="最高">最高</option>
												<option value="较高">较高</option>
												<option value="一般" selected="selected">一般</option>
												<option value="低">细微</option>
											</select>
										</td>
									</tr>
									<tr>
										<th class="category">
											<label for="profile_id">选择平台配置</label>
										</th>
										<td>

											<div id="profile_open" class=" collapse-closed noprint">
												<table class="table-bordered table-condensed">
													<tr>
														<th class="category" width="30%">
															<label for="platform">平台</label>
														</th>
														<td>
															<input type="text" id="platform" name="platform" class="typeahead input-sm" autocomplete="off" size="32" maxlength="32" tabindex="5" value="" />
														</td>
													</tr>
													<tr>
														<th class="category">
															<label for="os">操作系统</label>
														</th>
														<td>
															<input type="text" id="os" name="os" class="typeahead input-sm" autocomplete="off" size="32" maxlength="32" tabindex="6" value="" />
														</td>
													</tr>
													<tr>
														<th class="category">
															<label for="os_build">操作系统版本</label>
														</th>
														<td>
															<input type="text" id="os_build" name="os_build" class="typeahead input-sm" autocomplete="off" size="16" maxlength="16" tabindex="7" value="" />
														</td>
													</tr>
												</table>
											</div>
											<div id="profile_closed" class="collapse-section-closed  collapse-open">
											</div>
										</td>
									</tr>

									<tr>
										<th class="category">
											<label for="handler_id">分派给</label>
										</th>
										<td>
											<select tabindex="8" id="handler_id" name="handler_id" class="input-sm">
												<option value="<?php echo $_POST['username'] ?>" selected="selected"></option>
											</select>
										</td>
									</tr>

									<tr>
										<th class="category">
											<span class="required">*</span><label for="summary">摘要</label>
										</th>
										<td>
											<input tabindex="9" type="text" id="summary" name="summary" size="105" maxlength="128" value="" required />
										</td>
									</tr>
									<tr>
										<th class="category">
											<span class="required">*</span><label for="description">描述</label>
										</th>
										<td>
											<textarea class="form-control" tabindex="10" id="description" name="description" cols="80" rows="10" required></textarea>
										</td>
									</tr>

									<tr>
										<th class="category">
											<label for="steps_to_reproduce">问题重现步骤</label>
										</th>
										<td>
											<textarea class="form-control" tabindex="11" id="steps_to_reproduce" name="steps_to_reproduce" cols="80" rows="10">
</textarea>
										</td>
									</tr>

									<tr>
										<th class="category">
											<label for="additional_info">附注</label>
										</th>
										<td>
											<textarea class="form-control" tabindex="12" id="additional_info" name="additional_info" cols="80" rows="10"></textarea>
										</td>
									</tr>
									<tr>
										<th class="category">
											<label for="uploadfile">上传文件</label>
										</th>
										<td>
											<div id="dropzone-preview-template" class="hidden">
												<div class="dz-preview dz-file-preview">
													<div class="dz-filename"><span data-dz-name></span></div>
													<div><img data-dz-thumbnail /></div>
													<div class="dz-size" data-dz-size></div>
													<div class="progress progress-small progress-striped active">
														<div class="progress-bar progress-bar-success" data-dz-uploadprogress></div>
													</div>
													<div class="dz-success-mark"><span></span></div>
													<div class="dz-error-mark"><span></span></div>
													<div class="dz-error-message"><span data-dz-errormessage></span></div>
												</div>
											</div>
											<input type="hidden" name="max_file_size" value="5242880" />
											<div class="dropzone center" data-force-fallback="false" data-max-filesize-bytes="5242880" data-accepted-files="" data-default-message="通过拖放，选择或粘贴来附加文件。" data-fallback-message="您的浏览器不支持拖放文件上传。" data-fallback-text="" data-file-too-big="文件太大（{{filesize}}MiB）。最大文件大小：{{maxFilesize}}MiB。" data-invalid-file-type="您不能上传此类型的文件。" data-response-error="服务器响应了{{statusCode}}代码。" data-cancel-upload="取消上传" data-cancel-upload-confirmation="您确定要取消此次上传么？" data-remove-file="移除文件" data-remove-file-confirmation="" data-max-files-exceeded="您不能上传更多文件。" data-dropzone-not-supported="Dropzone.js不支持旧浏览器！" data-dropzone_multiple_files_too_big="下列文件:{{files}}超出了最大文件限制 ({{maxFilesize}} MiB)">
												<i class="fa fa-cloud-upload upload-icon ace-icon blue fa-3x"></i> <br>
												<div id="dropzone-previews-box" class="dropzone-previews dz-max-files-reached"></div>
											</div>
											<div class="fallback">
												<div class="dz-message" data-dz-message></div>
												<input tabindex="14" id="uploadfile" name="uploadfile" type="file" size="60" />
											</div>
										</td>
									</tr>

									<tr>
										<th class="category">
											查看权限 </th>
										<td>
											<label>
												<input tabindex="15" type="radio" class="ace" name="view_state"  checked="checked" />
												<span class="lbl padding-6">公开</span>
											</label>
											&#160;&#160;&#160;&#160;
											<label>
												<input tabindex="16" type="radio" class="ace" name="view_state"  />
												<span class="lbl padding-6">私有</span>
											</label>
										</td>
									</tr>
									<tr>
										<th class="category">
											继续报告 </th>
										<td>
											<label>
												<input tabindex="17" type="checkbox" class="ace" id="report_stay" name="report_stay" />
												<span class="lbl padding-6">报告更多的问题</span>
											</label>
										</td>
									</tr>
								</table>
							</div>
						</div>
						<div class="widget-toolbox padding-8 clearfix">
							<span class="required pull-right"> * 必填</span>
							<input tabindex="18" type="submit" class="btn btn-primary btn-white btn-round" value="提交问题" />
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
</div>
</body>




<!--
	<tr>
		<th class="category">
			<label for="reproducibility">严重等级</label>
		</th>
		<td>
			<select tabindex="2" id="reproducibility" name="reproducibility" class="input-sm">
				<option value="非常严重的缺陷">非常严重的缺陷</option>
                <option value="较严重的缺陷">较严重的缺陷</option>
                <option value="软件一般缺陷">软件一般缺陷</option>
                <option value="软件界面的细微缺陷" selected="selected">软件界面的细微缺陷</option>			
            </select>
		</td>
	</tr>
	<tr>
		<th class="category">
			<label for="severity">问题类型</label>
		</th>
		<td>
			<select tabindex="3" id="severity" name="severity" class="input-sm">
				<option value="UI异常">UI异常</option>
                <option value="运行失败">运行失败</option>
                <option value="功能异常">功能异常</option>
                <option value="安装失败">安装失败</option>
                <option value="启动失败" >启动失败</option>
                <option value="其他报错" selected="selected">其他报错</option>			
            </select>
		</td>
	</tr>
	<tr>
		<th class="category">
			<label for="priority">优先级</label>
		</th>
		<td>
			<select tabindex="4" id="priority" name="priority" class="input-sm">
				<option value="最高">最高</option>
                <option value="较高">较高</option>
                <option value="一般" selected="selected">一般</option>
                <option value="低">低</option>			
            </select>
		</td>
	</tr>
	-->