<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN" "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
    <title>查看问题</title>
    <?php include "./com/link.php"; ?>
    <?php include "./com/menu.php"; ?>
    <?php include "./com/database.php"; ?>
</head>
<div class="col-md-12 col-xs-12">
    <div class="space-10"></div>
    <form id="bug_action" method="post" action="bug_actiongroup_page.php">
        <div class="widget-box widget-color-blue2">
            <div class="widget-header widget-header-small">
                <h4 class="widget-title lighter">
                    <i class="fa fa-columns ace-icon"></i> 查看问题 <span class="badge"> 0 - 0 / 0</span>
                </h4>
            </div>

            <div class="widget-body">

                <div class="widget-toolbox padding-8 clearfix">
                    <div class="btn-toolbar">
                        <div class="btn-group pull-left">
                            <a class="btn btn-primary btn-white btn-round btn-sm" href="print_all_bug_page.php">打印报告</a><a class="btn btn-primary btn-white btn-round btn-sm" href="csv_export.php">导出为CSV</a><a class="btn btn-primary btn-white btn-round btn-sm" href="excel_xml_export.php">导出为Excel</a><a class="btn btn-primary btn-white btn-round btn-sm" href="view_all_set.php?summary=1&amp;temporary=y">摘要</a>
                        </div>
                        <div class="btn-group pull-right"> </div>
                    </div>
                </div>

                <div class="widget-main no-padding">
                    <div class="table-responsive checkbox-range-selection">
                        <table id="buglist" class="table table-bordered table-condensed table-hover table-striped">
                            <thead>
                                <tr class="buglist-headers">
                                    <th class="column-selection"> &#160; </th>
                                    <th class="column-edit"> &#160; </th>
                                    <th class="column-priority"><a href="view_all_set.php?sort_add=priority&amp;dir_add=ASC&amp;type=2">P</a></th>
                                    <th class="column-id"><a href="view_all_set.php?sort_add=id&amp;dir_add=ASC&amp;type=2">编号</a></th>
                                    <th class="column-bugnotes-count"><i class="fa fa-comments blue"></i></th>
                                    <th class="column-attachments"><i class="fa fa-paperclip blue" title="附件计数"></i></th>
                                    <th class="column-category"><a href="view_all_set.php?sort_add=category_id&amp;dir_add=ASC&amp;type=2">分类</a></th>
                                    <th class="column-severity"><a href="view_all_set.php?sort_add=severity&amp;dir_add=ASC&amp;type=2">严重性</a></th>
                                    <th class="column-status"><a href="view_all_set.php?sort_add=status&amp;dir_add=ASC&amp;type=2">状态</a></th>
                                    <th class="column-last-modified"><a href="view_all_set.php?sort_add=last_updated&amp;dir_add=ASC&amp;type=2">最后更新</a>&#160;<i class="fa fa-caret-down fa-lg blue"></i></th>
                                    <th class="column-summary"><a href="view_all_set.php?sort_add=summary&amp;dir_add=ASC&amp;type=2">摘要</a></th>
                                </tr>

                            </thead>
                            <tbody>


                            </tbody>
                        </table>
                    </div>

                    <div class="widget-toolbox padding-8 clearfix">
                        <div class="form-inline pull-left">
                            &#160; </div>
                        <div class="btn-group pull-right">
                        </div>
                    </div>