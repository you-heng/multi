<meta http-equiv="Content-Type" content="text/html;charset=utf-8" > 
<li><a href="./doLogin/login.php"><span class="glyphicon glyphicon-log-out"></span>注销</a></li>