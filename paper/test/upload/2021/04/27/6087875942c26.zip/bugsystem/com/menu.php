<!--<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN" "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
    <link rel="stylesheet" type="text/css" href="./lib/css/status_config.php?cache_key=cffebea471352003bcc9c570080f8603" />
    <link rel="stylesheet" type="text/css" href="./lib/css/dropzone-5.5.0.min.css" />
    <link rel="stylesheet" type="text/css" href="./lib/css/default.css" />
    <link rel="stylesheet" type="text/css" href="./lib/css/bootstrap-3.4.0.min.css" />
    <link rel="stylesheet" type="text/css" href="./lib/css/font-awesome-4.6.3.min.css" />
    <link rel="stylesheet" type="text/css" href="./lib/css/fonts.css" />
    <link rel="stylesheet" type="text/css" href="./lib/css/bootstrap-datetimepicker-4.17.47.min.css" />
    <link rel="stylesheet" type="text/css" href="./lib/css/ace.min.css" />
    <link rel="stylesheet" type="text/css" href="./lib/css/ace-mantis.css" />
    <link rel="stylesheet" type="text/css" href="./lib/css/ace-skins.min.css" />
    <link rel="shortcut icon" href="./lib/images/favicon.ico" type="image/x-icon" />
    <script type="text/javascript" src="/lib/js/jquery-2.2.4.min.js"></script>
    <script type="text/javascript" src="/lib/js/dropzone-5.5.0.min.js"></script>
    <script type="text/javascript" src="/lib/js/common.js"></script>
</head>

<body class="skin-3">
    <style>
        * {
            font-family: "Open Sans";
        }

        h1,
        h2,
        h3,
        h4,
        h5 {
            font-family: "Open Sans";
        }
    </style>
    <div id="navbar" class="navbar navbar-default navbar-collapse navbar-fixed-top noprint">
            <div class="navbar-header"><a href="./my_view_page.php" class="navbar-brand">
            <span class="smaller-75">缺陷管理系统</span></a>
            <button type="button" class="navbar-toggle navbar-toggle collapsed pull-right hidden-sm hidden-md hidden-lg" data-toggle="collapse" data-target=".navbar-buttons,.navbar-menu">
            <span class="sr-only">Toggle user menu</span><i class="ace-icon fa fa-user fa-2x white"></i> </button></div>
            <div class="navbar-buttons navbar-header navbar-collapse collapse">
                <ul class="nav ace-nav">
                    <li class="hidden-sm hidden-xs">
                        <div class="btn-group btn-corner padding-right-8 padding-left-8">
                        <a class="btn btn-primary btn-sm" href="bug_report_page.php">
                        <i class="fa fa-edit"></i> 提交问题</a><a class="btn btn-primary btn-sm" href="manage_user_create_page.php">
                        <i class="fa fa-user-plus"></i> 邀请用户</a></div>
                    </li>
                    <li class="grey" id="dropdown_projects_menu">
                        <a data-toggle="dropdown" href="#" class="dropdown-toggle">
                            &#160;所有项目&#160;
                            <i class="ace-icon fa fa-angle-down bigger-110"></i>
                        </a>
                        <ul id="projects-list" class=" dropdown-menu dropdown-menu-right dropdown-yellow dropdown-caret dropdown-close">
                            <li>
                                <div class="projects-searchbox"><input class="search form-control input-md" placeholder="搜索" /></div>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <div class="scrollable-menu">
                                    <ul class="list dropdown-yellow no-margin">
                                        <li><a href="./set_project.php?project_id=0">所有项目 </a></li>
                                        <li class="divider"></li>
                                        <li><a href="./set_project.php?project_id=11" class="project-link"> 购物商城 </a></li>
                                        <li class="active"><a href="./set_project.php?project_id=9" class="project-link">中国银行测试项目 </a></li>
                                        <li><a href="./set_project.php?project_id=8" class="project-link"> 农业银行测试项目 </a></li>
                                        <li><a href="./set_project.php?project_id=13" class="project-link"> 交通银行测试项目 </a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li class="grey"><a data-toggle="dropdown" href="#" class="dropdown-toggle"><i class="ace-icon fa fa-user fa-2x white"></i> <span class="user-info">administrator</span><i class="ace-icon fa fa-angle-down"></i></a>
                        <ul class="user-menu dropdown-menu dropdown-menu-right dropdown-yellow dropdown-caret dropdown-close">
                            <li><a href="./account_page.php"><i class="ace-icon fa fa-user"> </i> 个人资料</a></li>
                            <li class="divider"></li>
                            <li><a href="./exit.php"><i class="ace-icon fa fa-sign-out"> </i> 注销</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="main-container" id="main-container">
        <div id="sidebar" class="sidebar sidebar-fixed responsive compact ">
            <ul class="nav nav-list">
                <li>
                    <a href="./my_view_page.php">
                        <i class="menu-icon fa fa-dashboard"></i>
                        <span class="menu-text"> 我的视图 </span>
                    </a>
                   
                </li>
                <li>
                    <a href="./view_all_bug_page.php">
                        <i class="menu-icon fa fa-list-alt"></i>
                        <span class="menu-text"> 查看问题 </span>
                    </a>
                    
                </li>
                <li>
                    <a href="./bug_report_page.php">
                        <i class="menu-icon fa fa-edit"></i>
                        <span class="menu-text"> 提交问题 </span>
                    </a>
                    
                </li>
                <li>
                    <a href="./summary_page.php">
                        <i class="menu-icon fa fa-bar-chart-o"></i>
                        <span class="menu-text"> 摘要 </span>
                    </a>
                    
                </li>
                <li class="active">
                    <a href="./manage_overview_page.php">
                        <i class="menu-icon fa fa-gears"></i>
                        <span class="menu-text"> 管理 </span>
                    </a>
                    <b class="arrow"></b>
                </li>
                <li class="active">
                    <a href="./role_manage.php">
                        <i class="menu-icon fa fa-gears"></i>
                        <span class="menu-text"> 角色管理 </span>
                    </a>
                  
                </li>
                <li class="active">
                    <a href="./menu_manage.php">
                        <i class="menu-icon fa fa-gears"></i>
                        <span class="menu-text"> 菜单管理 </span>
                    </a>
                   
                </li>
            </ul>
            <div id="sidebar-btn" class="sidebar-toggle sidebar-collapse">
                <i data-icon2="ace-icon fa fa-angle-double-right" data-icon1="ace-icon fa fa-angle-double-left" class="ace-icon fa fa-angle-double-left"></i>
            </div>
        </div>
        <div class="main-content">
            <div id="breadcrumbs" class="breadcrumbs noprint">
                <ul class="breadcrumb">
                    <li><i class="fa fa-user home-icon active"></i> <a href="./account_page.php">administrator</a>
                        <span class="label hidden-xs label-default arrowed">管理员</span>
                    </li>
                </ul>
                <div id="nav-search" class="nav-search">
                    <form class="form-search" method="post" action="./jump_to_bug.php">
                        <span class="input-icon">
                            <input type="text" name="bug_id" autocomplete="off" class="nav-search-input" placeholder="问题 #">
                            <i class="ace-icon fa fa-search nav-search-icon"></i>
                        </span>
                    </form>
                </div>
            </div>-->
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" > 
<?php
//判断权限信息
session_start();
if(!isset($_SESSION['menu_info'])){
    Header("refresh:3;url=doLogin/login.php");
    print('请重新登录...<br>3秒后自动跳转');
    exit;
}
?>
<div class="col-md-12" style="padding-top: 10px;">

    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand">缺陷管理系统</a>
            </div>
            <u1 class="nav navbar-nav">
                <li><a href="index.php"> 首页</a></li>
                <?php
                for($i=0;$i<count($_SESSION['menu_info'],0);$i++){
                    echo '<li><a href="'.$_SESSION['url_menu'][$i].'">'.$_SESSION['menu_info'][$i].'</a></li>';
                }
                ?>
                <!--
                <li><a href="my_view_page.php"> 我的视图</a></li>
                <li><a href="view_all_bug_page.php"> 查看问题</a></li>
                <li><a href="bug_report_page.php">  提交问题</a></li>
                <li><a href="summary_page.php"> 摘要 </a></li>
                <li><a href="role_manage.php"> 角色管理</a></li>
                <li><a href="menu_manage.php"> 菜单管理</a></li>
                <li><a href="manage_overview_page.php"> 管理</a></li>
                <li><a href="upload_pic.php">轮播图设定</a></li>
                <li><a href="account_page.php">个人资料</a></li>
                -->
            </u1>
            <u1 class="nav navbar-nav navbar-right">
                <li><a href="./doLogin/login.php"><span class="glyphicon glyphicon-log-out"></span>退出</a></li>
            </u1>
        </div>
    </nav>
</div>
            