<?php include "./com/database.php";?>
<?php
$role_id=$_POST['role_id'];
//先删除
$sql_str="delete from t_role_menu where role_id='$role_id'";
del_insert_update_sql($sql_str);
$list_fav=$_POST['menus'];
foreach($list_fav as $value){
    $insert_sql="INSERT INTO t_role_menu(role_id,menu_id) values (".$role_id.",".$value.")";
    del_insert_update_sql($insert_sql);
}
Header("Location:role_manage.php");
?>