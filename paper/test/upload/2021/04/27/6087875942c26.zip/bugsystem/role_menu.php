<meta http-equiv="Content-Type" content="test/html;charset=UTF-8">
        <?php include "./com/link.php";?>
        <?php include "./com/menu.php";?>
        <?php include "./com/database.php";?>
        <?php
        $role_id=$_GET['role_id'];
        $sql_get_menu="select * from t_menu";
        $res_menu_list=get_sql_list($sql_get_menu);
        ?>
        <div class="col-lg-4 col-lg-offset-4" style="padding-top:100px">
        <center>
            <h3>用户权限设定</h3>
        </center>
        <br>
        <form id="form" name="form" action="role_menu_update.php" method="post">
            <input type="hidden" name='role_id' value="<?=$role_id?>">
            <p>菜单权限：
                <?php
                $html='';
                if(mysqli_num_rows($res_menu_list)>0){
                    //输出数据
                    while($list_info=mysqli_fetch_array($res_menu_list)){
                        $html .='<label><input type="checkbox" name="menus[]" value="'.$list_info['id'].'"/>'.$list_info['menu_name'].'</table>';
                    }
                    echo $html;
                }
               ?>
            </p>
            <p><input name="tijiao" value="提交" type="submit"><input name="cacel" value="取消" type="reset"></p>
        </form>
        </div>
        