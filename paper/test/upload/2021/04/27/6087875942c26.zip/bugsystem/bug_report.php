<?php include "./com/database.php";?>
<?php
$proj_name=$_POST['proj_name'];
$reproducibility=$_POST['reproducibility'];
$severity=$_POST['severity'];
$priorty=$_POST['priority'];
$platform=$_POST['platform'];
$os=$_POST['os'];
$osbuild=$_POST['os_build'];
$summary=$_POST['summary'];
$description=$_POST['description'];
$step=$_POST['steps_to_reproduce'];
$additional_info=$_POST['additional_info'];
$state=$_POST['view_state'];
getConnection();
  $sql="insert into bug(proj_name,reproducibility,severity,priority,platform,os,os_build,summary,description,steps_to_reproduce,view_state) 
  values('$proj_name','$reproducibility','$severity','$priority','$platform','$os','$osbuild','$summary','$description','$step','$state')";
  $result=del_insert_update_sql($sql);
closeConnection();
  if($result){
      echo '添加成功<a href="bug_report_page.php"></a>';
  }else{
      echo "添加失败";
  } 
?>