<?php 
$databaseConnection = null;
function getConnection(){
	$hostname = "localhost"; //数据库服务器主机名,可以用IP代替
	$database = "second"; //数据库名
	$userName = "root"; //数据库服务器用户名
	$password = ""; //数据库服务器密码
	global $databaseConnection;
	$databaseConnection = @mysqli_connect($hostname, $userName, $password) or die(mysqli_error($databaseConnection));  //连接数据库服务器
	 //设置字符集
	 $program_char = "utf8" ;
	 mysqli_set_charset( $databaseConnection , $program_char );	 
	 @mysqli_select_db( $databaseConnection,$database) or die(mysqli_error($databaseConnection));
}
//数据查找
function get_sql_list($sql_info){
	global $databaseConnection;
	getConnection();
	$list=mysqli_query($databaseConnection,$sql_info);
	closeConnection();
	return $list;
}
//数据新增、删除、修改
function del_insert_update_sql($sql_info)
{
	global $databaseConnection;
	getConnection();
	mysqli_query( $databaseConnection,$sql_info);
	closeConnection();

}
function closeConnection(){
	global $databaseConnection;
	if($databaseConnection){
		mysqli_close($databaseConnection) or die(mysqli_error($databaseConnection));
	}
}?>
