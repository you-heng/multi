<?php 
session_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN" "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8">
	<?php include "./com/link.php"; ?>
	<?php include "./com/menu.php"; ?>
	<?php include "./com/database.php"; ?>
</head>

<body>
<?php
    define ('MYSQLI_ASSOC',1);
    $sql_user="SELECT * from t_user where username='".$_SESSION['logged']."'";
	$user_list=get_sql_list($sql_user);
   if(mysqli_num_rows($user_list)>0){
	 //输出数据
	 while($list_info = mysqli_fetch_array($user_list,MYSQLI_ASSOC)){
		//print_r($list_info);
		//echo $list_info["username"];
		//echo $list_info["realname"];
		//echo $list_info['email'];
		//echo $list_info["pwd"];
		//echo $list_info["role_name"];
	 }
	}else{
	  echo "当前用户不存在";
	  exit;
  }
?>
	</ul>
	<div id="sidebar-btn" class="sidebar-toggle sidebar-collapse">
		<i data-icon2="ace-icon fa fa-angle-double-right" data-icon1="ace-icon fa fa-angle-double-left" class="ace-icon fa fa-angle-double-left"></i>
	</div>
	</div>
	<div class="main-content">
		<div class="page-content">
			<div class="row">
				<ul class="nav nav-tabs padding-18">
					<li class="active">
						<a href="./account_page.php">
							个人资料修改</a>
					</li>
				</ul>

				<div class="col-md-12 col-xs-12">
					<div class="space-10"></div>

					<div id="account-update-div" class="form-container">
						<form id="account-update-form" method="post" action="account_update.php">

							<div class="widget-box widget-color-blue2">
								<div class="widget-header widget-header-small">
									<h4 class="widget-title lighter">
										<i class="ace-icon fa fa-user"></i>
										<center>编辑帐号</center>
									
									</h4>
								</div>
							    <form action="account_page_update.php" method="post" onsubmit="return Validator.Validate(this,3)">
								<div class="widget-body">
									<div class="widget-main no-padding">
										<div class="table-responsive">
											<table class="table table-bordered table-condensed table-striped">
												<fieldset>
													<input type="hidden" name="account_update_token" value="2021030912PanrYuLHfrjSVhJl4fttUrJUVejH8U" />
													<tr>
														<td align="center" class="category">
															用户名 </td>
														<td>
														<input class="input-sm" id="username" type="text" name="username" size="32"  value="<?php echo $list_info["username"]?>"  maxlength="1024" required />
														</td>
													</tr>
													<tr>
														<td align="center" class="category">真实姓名</td>
														<td><input class="input-sm" id="realname" type="text" size="32" maxlength="255" name="realname" value="<?php $list_info["realname"]?>" /></td>
													</tr>
													<tr>
														<td align="center" class="category">
															<span class="required" required> * </span> 当前密码
														</td>
														<td>
															<input class="input-sm" id="password-current" type="password" name="password_current" size="32" maxlength="1024" value="<?php $list_info['pwd']?>" required />
														</td>
													</tr>
													<tr>
														<td align="center" class="category">
															<span class="required" required> * </span> 新密码
														</td>
														<td>
															<input class="input-sm" id="password" type="password" name="password" size="32" maxlength="1024" required />
														</td>
													</tr>
													<tr>
														<td align="center" class="category">
															<span class="required" required> * </span> 确认密码
														</td>
														<td>
															<input class="input-sm" id="password-confirm" type="password" name="password_confirm" size="32" maxlength="1024" required />
														</td>
													</tr>
													<tr>
														<td align="center" class="category">
															电子邮件 </td>
														<td>
															<input class="input-sm" id="email-field" type="text" name="email" size="32" maxlength="64" value="" />
														</td>
													</tr>
													
													<tr>
														<td align="center" class="category">
															操作权限 </td>
														<td><select id="user-role" name="role"  class="input-sm">
																<option value="开发人员">开发人员</option>
																<option value="测试人员" selected="selected">测试人员</option>
																<option value="管理员">管理员</option>
															</select></td>
													</tr>
													<tr>
														<td align="center" class="category">
															项目访问级别 </td>
														<td>
															<select id="user-access-level" name="access_level" class="input-sm">
																<option value="开发人员">开发人员</option>
																<option value="测试人员" selected="selected">测试人员</option>
																<option value="管理员">管理员</option>
															</select>
														</td>
													</tr>
												</fieldset>
											</table>
											</form>
										</div>
									</div>
									<div class="widget-toolbox padding-8 clearfix">
										<span class="required pull-right"> * 必填</span>
										<input type="submit" class="btn btn-primary btn-white btn-round" value="更新帐号信息" />
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>