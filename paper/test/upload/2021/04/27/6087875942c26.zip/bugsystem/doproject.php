<?php include "./com/database.php";?>
<?php
session_start();
$id = $_POST['project_id'];
$proj_name = $_POST['proj_name']; 
$status = $_POST['status'];
$view_state= $_POST['view_state'];
$description = $_POST['description'];
$sql_project = "UPDATE project SET proj_name = '$proj_name', status='$status', view_state='$view_state',description='$description' WHERE id='$id'";
$project_list=del_insert_update_sql($sql_project);
if($project_list)
{
  alert("编辑成功");
  href("manage_proj_page.php");
}else{
  alert("编辑失败");
}
function alert($title){
  echo "<script type='text/javascript'>alert('$title');</script>";
}
function href($url){
  echo "<script type='text/javascript'>window.location.href='$url'</script>";
}
?>