<?php include "../com/database.php"; ?>
<?php
session_start();
$username = $_POST['username'];
$pwd = $_POST['pwd'];
if ($username==""){
    echo "请输入用户名，请重新登录。". "<a href='login.php'>返回登录</a>";
    exit;
}
if ($pwd==""){
    echo "请输入有效的密码，请重新登录。". "<a href='login.php'>返回登录</a>";
    exit;
}
$sql_get_user="SELECT * from t_user where username='".$username."' and pwd='".$pwd."'";
$res_user_list=get_sql_list($sql_get_user);
if(mysqli_num_rows($res_user_list)){
    $_SESSION['logged']=$username;
    echo "登录成功。"."<a href='account_page.php'></a>";
}else{
    echo "用户名密码错误"."<a href='login.php'>返回登录</a>";
}
if(mysqli_num_rows($res_user_list)>0){
    //输出数据
 $row=mysqli_fetch_assoc($res_user_list);

 //获取权限信息
 $sql_get_menuInfo="SELECT menu_name,url_menu from t_role_menu LEFT JOIN t_menu ON t_role_menu.menu_id=t_menu.id where t_role_menu.role_id=".$row['role_id'];
 $res_menuInfo_list=get_sql_list($sql_get_menuInfo);
 $i=0;
 $_SESSION['menu_info']=[];
 $_SESSION['url_menu']=[];
 while($list_info=mysqli_fetch_array($res_menuInfo_list)){
     $_SESSION['menu_info'][$i]=$list_info['menu_name'];
     $_SESSION['url_menu'][$i]=$list_info['url_menu'];
     $i++;
 }
     $showIndex_url="../my_view_page.php?";
     Header("Location:$showIndex_url");
}else{
    echo "用户名密码错误，请重新登录。"."<a href='login.php'>返回登录</a>";
}
?>