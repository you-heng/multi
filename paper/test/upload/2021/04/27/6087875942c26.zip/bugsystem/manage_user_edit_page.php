<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <title>问题详情</title>
    <?php include "./com/link.php"; ?>
    <?php include "./com/menu.php"; ?>
    <?php include "./com/database.php"; ?>
</head>
<div class="col-md-12 col-xs-12">
    <div class="space-10"></div>

    <!-- USER INFO -->
    <div id="edit-user-div" class="form-container">
        <form id="edit-user-form" method="post" action="manage_user_update.php">
            <div class="widget-box widget-color-blue2">
                <div class="widget-header widget-header-small">
                    <h4 class="widget-title lighter">
                        <i class="ace-icon fa fa-user"></i>
                        编辑用户
                    </h4>
                </div>
                <div class="widget-body">
                    <div class="widget-main no-padding">
                        <div class="form-container">
                            <div class="table-responsive">
                                <table class="table table-bordered table-condensed table-striped">
                                    <fieldset>
                                        <input type="hidden" name="manage_user_update_token" value="20210311UCc55bd9aVxShPaM9KyEF9LOLICPwGHt" /> <!-- Title -->
                                        <input type="hidden" name="user_id" value="19" />

                                        <!-- Username -->
                                        <tr>
                                            <td class="category">
                                                用户名 </td>
                                            <td>
                                                <input id="edit-username" type="text" class="input-sm" size="32" maxlength="191" name="username" value="chair" />
                                            </td>
                                        </tr>

                                        <!-- Realname -->
                                        <tr>
                                            <td class="category">真实姓名</td>
                                            <td><input id="edit-realname" type="text" class="input-sm" size="32" maxlength="255" name="realname" value="" /></td>
                                        </tr>
                                        <!-- Email -->
                                        <tr>
                                            <td class="category">电子邮件</td>
                                            <td><input class="input-sm" id="email-field" type="text" name="email" size="32" maxlength="64" value="332039038@qq.com" /></td>
                                        </tr>
                                        <!-- Access Level -->
                                        <tr>
                                            <td class="category">
                                                操作权限 </td>
                                            <td>
                                                <select id="edit-access-level" name="access_level" class="input-sm">
                                                    <option value="">管理员</option>
                                                    <option value="" selected="selected">测试人员</option>
                                                    <option value="">开发人员</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <!-- Enabled Checkbox -->
                                        <tr>
                                            <td class="category">
                                                已启用 </td>
                                            <td>
                                                <label>
                                                    <input type="checkbox" class="ace" id="edit-enabled" name="enabled" checked="checked">
                                                    <span class="lbl"></span>
                                                </label>
                                            </td>
                                        </tr>
                                        <!-- Protected Checkbox -->
                                        <tr>
                                            <td class="category">
                                                已保护 </td>
                                            <td>
                                                <label>
                                                    <input type="checkbox" class="ace" id="edit-protected" name="protected">
                                                    <span class="lbl"></span>
                                                </label>
                                            </td>
                                        </tr>


                                        <!-- Submit Button -->
                                    </fieldset>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="space-10"></div>
    <div id="manage-user-actions-div" class="col-md-6 col-xs-12 no-padding">
        <div class="space-8"></div>
        <div class="btn-group">

            <!-- Reset/Unlock Button -->
            <form id="manage-user-reset-form" method="post" action="manage_user_reset.php" class="pull-left">
                <fieldset>
                    <input type="hidden" name="manage_user_reset_token" value="202103119In9xRYUTAH7Qz-WgzS7NixUHzOTtejx" /> 
                    <input type="hidden" name="user_id" value="19" />
                    <span><input type="submit" class="btn btn-primary btn-white btn-round" value="重设密码" /></span>
                </fieldset>
            </form>

            <!-- Delete Button -->
            <form id="manage-user-delete-form" method="post" action="manage_user_delete.php" class="pull-left">
                <fieldset>
                    <input type="hidden" name="manage_user_delete_token" value="202103115e02yD1eZ8Mr3w_u-81O4gs7UErNDba3" /> 
                    <input type="hidden" name="user_id" value="19" />
                    <span><input type="submit" class="btn btn-primary btn-white btn-round" value="删除用户" /></span>
                </fieldset>
            </form>

            <!-- Impersonate Button -->
            <form id="manage-user-impersonate-form" method="post" action="manage_user_impersonate.php" class="pull-left">
                <fieldset>
                    <input type="hidden" name="manage_user_impersonate_token" value="20210311kY0lvTr-UuK4rkIkoQ_4j9Sk0k9uN-lb" /> 
                    <input type="hidden" name="user_id" value="19" />
                    <input type="submit" class="btn btn-primary btn-white btn-round" value="模仿用户" />
                </fieldset>
            </form>

        </div>
    </div>

    <div class="clearfix"></div>

    <!-- PROJECT ACCESS (if permissions allow) and user is not ADMINISTRATOR -->
    <div class="space-10"></div>
    <div class="widget-box widget-color-blue2">
        <div class="widget-header widget-header-small">
            <h4 class="widget-title lighter">
                <i class="ace-icon fa fa-puzzle-piece"></i>
                添加用户至项目
            </h4>
        </div>

        <div class="widget-body">
            <div class="widget-main no-padding">
                <div class="form-container">
                    <div class="table-responsive">
                        <table class="table table-bordered table-condensed table-striped">
                            <tr>
                                <td class="category">
                                    已分配项目 </td>
                                <td>
                                <form method="post" action="manage_user_proj_delete.php" class="form-inline">
                                    <fieldset>
                                    <input type="hidden" name="manage_user_proj_delete_token" value="20210311Vu6NVhW2aLfr3avfFOShrefJD6Uf8D9i" /> <input type="hidden" name="project_id" value="13" />
                                    <input type="hidden" name="user_id" value="19" />
                                    <input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="移除" />
                                    </fieldset>
                                </form>
                                <br />
                                <form method="post" action="manage_user_proj_delete.php" class="form-inline">
                                    <fieldset>
                                    <input type="hidden" name="manage_user_proj_delete_token" value="20210311YGEw0qMsakaAnldFRF8-GzpDoGm8PEsI" /> <input type="hidden" name="project_id" value="10" />
                                    <input type="hidden" name="user_id" value="19" />
                                    <input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="移除" />
                                    </fieldset>
                                </form>
                                <br />
                                </td>
                            </tr>
                            <form id="manage-user-project-add-form" method="post" action="manage_user_proj_add.php">
                                <fieldset>
                                    <input type="hidden" name="manage_user_proj_add_token" value="2021031164Wr4peMf4aQ5MjwO7ONIPXxGh4Oxq0N" /> <input type="hidden" name="user_id" value="19" />
                                    <tr>
                                        <td class="category">
                                            未分配项目 </td>
                                        <td>
                                            <select id="add-user-project-id" name="project_id[]" class="input-sm" multiple="multiple" size="5">
                                                <option value="11">购物商城</option>
                                                <option value="9">中国银行测试项目</option>
                                                <option value="8">农业银行测试项目</option>
                                                <option value="7">交通银行测试项目</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="category">
                                            操作权限 </td>
                                        <td>
                                            <select id="add-user-project-access" name="access_level" class="input-sm">
                                                <option value="">管理员</option>
                                                <option value="" selected="selected">测试人员</option>
                                                <option value="">开发人员</option>
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <input type="submit" class="btn btn-primary btn-sm btn-white btn-round" value="添加用户" />
                                        </td>
                                    </tr>
                                </fieldset>
                            </form>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>