<div class="col-md-12" style="padding-top: 0px;">
<div id="imgs" data-interval="2000" data-ride="carousel" class="carousel slide" style="width: 100%">
     <div class="carousel-inner">

            <div class="item active">

                <img src="./img/img0001.jpg" style="width: 100%;height: 300px;">

            </div>

            <div class="item">

                <img src="./img/img0002.jpg" style="width: 100%;height: 300px;">

            </div>

            <div class="item">

                <img src="./img/img0003.jpg" style="width: 100%;height: 300px;">

            </div>

            <div class="item">

                <img src="./img/img0004.jpg" style="width: 100%;height: 300px;">

            </div>

            <ul class="carousel-indicators">

                <li data-target="#imgs" data-slide-to="0" class="active"></li>

                <li data-target="#imgs" data-slide-to="1"></li>

                <li data-target="#imgs" data-slide-to="2"></li>

                <li data-target="#imgs" data-slide-to="3"></li>

            </ul>

        </div>

        <a href="#imgs" data-slide="prev" class="carousel-control left" style="margin-top:100px;">
            <</a> <a href="#imgs" data-slide="next" class="carousel-control right" style="margin-top:100px;">>
        </a>

    </div>

