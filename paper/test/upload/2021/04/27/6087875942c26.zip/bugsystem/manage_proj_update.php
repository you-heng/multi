<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transtitional//EN" "http://www.w3.org/TR/xhtml1/DHD/xhtml1-tansitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
    <title>编辑项目</title>
    <?php include "./com/link.php"; ?>
    <?php include "./com/menu.php"; ?>
    <?php include "./com/database.php"; ?>
</head>
<body>
<?php
$id = $_GET['project_id'];
$sql_project = "select * from project where id='$id'";
$project_list = get_sql_list($sql_project);
if (mysqli_num_rows($project_list) > 0) {
    //输出数据
    while ($list_info = mysqli_fetch_array($project_list, MYSQLI_ASSOC)) {
        //print_r($list_info);
        //echo $list_info['proj_name'];
        //echo $list_info['status'];
        //echo $list_info['view_state'];
    }
} else {
    echo "未找到项目";
    exit;
}
?>
    <center>
        <h3>项目信息修改</h3>
    </center>
<div class="col-lg-4 col-lg-offset-4" style="padding-top:100px">
        <form action="doproject.php" method="post">
            <input type="hidden" name="project_id" value="<?php echo $list_info['id'] ?>" />
            <table style="border-collapse:collapse" border="1" width="80%" cellpadding="10"  bordercolor="gray">
                <tr>
                    <td align="center"> 项目名称</td>
                    <td>&nbsp;<input type="text" name="proj_name" size="10" value=<?php echo $list_info['proj_name'] ?>></td>
                    <br />
                </tr>
                <tr>
                    <td align="center">状态 </td>
                    <td>
                        <select id="project-status" name="status" class="input-sm" value=<?php echo $list_info['status'] ?>>
                            <option value="开发中">开发中</option>
                            <option value="已发布">已发布</option>
                            <option value="稳定">稳定</option>
                            <option value="停止维护">停止维护</option>
                        </select>
                    </td>
                </tr>


                <tr>
                    <td align="center">查看权限 </td>
                    <td>
                        <select id="project-view-state" name="view_state" class="input-sm" value=<?php echo $list_info['view_state'] ?>>
                            <option value="公开" selected="selected">公开</option>
                            <option value="私有">私有</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td align="center">描述 </td>
                    <td>
                        <textarea class="form-control" id="project-description" name="description" cols="70" rows="5"><?php echo $list_info['description'] ?></textarea>
                    </td>
                </tr>
                <tr>
                <td align="center" colspan="2" >
                <input type="submit" value="更新项目信息"></td>
                </tr>
            </table>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
            <p>&nbsp;</p>
        </form>
</div>

</html>
</body>