<meta http-equiv="Content-Type" content="test/html;charset=UTF-8">
<title>用户</title>
        <?php include "./com/link.php";?>
        <?php include "./com/menu.php";?>
        <?php include "./com/database.php";?>
        <?php include  "page.php";?>
        <?php 
        //查询结果条数
         $sql_user="select  count(1) total from t_user";
         $user_list=get_sql_list($sql_user);
        $list_info = mysqli_fetch_array($user_list);
        $count_rows = $list_info['total'];
        $perPage =2;
        $page = isset($_GET['page']) ? $_GET['page'] : 1;
        //引用分页函数
       pageft($count_rows, $count_rows, $perPage);
        $sql_user = "select * from t_user  limit $firstCount, $displayPG";
        $user_list =get_sql_list($sql_user);
        ?>
        <div class="col-md-12 col-xs-12">
    <div class="space-10"></div>
    <div class="widget-box widget-color-blue2">
        <div class="widget-header widget-header-small">
        </div>
        <div class="widget-body">
            <div class="widget-main no-padding">
                <div class="widget-toolbox padding-8 clearfix">
                    <form method="post" action="manage_user_create_page.php" class="form-inline inline single-button-form">
                        <fieldset>
                            <input type="hidden" name="manage_user_create_page_token" value="20210309JIVFgP0llRE_HhHq6NyzBW_vWrQqPom9" />
                            <button type="submit" class="btn btn-primary btn-white btn-round">
                            <span class="glyphicon glyphicon-plus"></span>
                            创建新账户</button>
                        </fieldset>
                    </form>
                </div>
            <div class="panel-body">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                        <th>序号</th>
                        <th>用户名</th>
                        <th>姓名</th>
						<th>密码</th>
                        <th>电子邮件</th>
                        <th>角色</th>
                        <th>操作</th>
                        </tr> 
                    </thead>
                    <?php
                        $html="";
                        $i = ($page - 1) * $perPage + 15;
                        if(mysqli_num_rows($user_list)>0){
                          //输出数据
                          while($list_info=mysqli_fetch_array($user_list)){
                              $html .='<tr>';
                              $html .='<td>'.$list_info["id"].'</td>';
                              $html .='<td>'.$list_info["username"].'</td>';
                              $html .='<td>'.$list_info["realname"].'</td>';
							  $html .='<td>'.$list_info["pwd"].'</td>';
                              $html .='<td>'.$list_info["email"].'</td>';
                              $html .='<td>'.$list_info["role_name"].'</td>';
                              $html .='<td> <a class="btn btn-primary" href="./manage_user_update.php?user_id='.$list_info["id"].'"><i class="fa fa-pencil"></i>修改</a>';
                              $html .='     <a class="btn btn-danger"  href="./manage_user_del.php?user_id=' .$list_info["id"].'"><i class="fa fa fa-trash-o"></i>删除</a></td>';
                              $html .='</tr>';
                          }
                          echo $html;
                      }else{
                          echo "暂无数据";
                      }
                    ?>
                </table>
                <?php
                echo $pageNav;
                ?>
            </div>
        </div>
        </div>
    </div>